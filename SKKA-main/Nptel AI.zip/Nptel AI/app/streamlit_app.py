"""
NPTEL Agentic RAG - Streamlit Interface (Modern Chat)
=====================================================

Interactive UI for querying NPTEL lectures with a modern chat interface.
"""

# Force UTF-8 for all stdout/stderr
import os
os.environ["PYTHONIOENCODING"] = "utf-8"

import streamlit as st
import json
import time
from datetime import datetime
from typing import Dict, Any, List
import logging
import sys
from pathlib import Path

# Add parent directory to path to allow importing pipeline
parent_dir = Path(__file__).parent.parent
sys.path.insert(0, str(parent_dir))

# Import Pipeline
from pipeline.simple_pipeline import create_pipeline

# Setup logging
if "logging_setup" not in st.session_state:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    st.session_state.logging_setup = True

# Page configuration
st.set_page_config(
    page_title="NPTEL Agentic RAG",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for Light Theme and Modern Look
st.markdown("""
<style>
    /* Styling for the entire app to ensure light theme */
    .stApp {
        background-color: #ffffff;
        color: #1f2937;
    }
    
    /* Chat message containers */
    .stChatMessage {
        background-color: transparent !important;
        border: none !important;
    }
    
    /* User message styling */
    .stChatMessage[data-testid="stChatMessage"] {
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
    }

    /* Agent status indicators */
    .agent-status {
        display: flex;
        align-items: center;
        padding: 0.5rem;
        margin: 0.2rem 0;
        border-radius: 6px;
        background: #f3f4f6; /* Light gray background */
        border: 1px solid #e5e7eb;
        color: #374151;
    }
    
    /* Header styling */
    h1 {
        font-family: 'Inter', sans-serif;
        font-weight: 700;
        color: #111827 !important;
    }
    
    /* Sidebar polish */
    [data-testid="stSidebar"] {
        background-color: #f9fafb;
        border-right: 1px solid #e5e7eb;
    }
    
    .stButton button {
        border-radius: 6px;
    }
</style>
""", unsafe_allow_html=True)


def render_header():
    st.markdown("""
    <div style="text-align: center; margin-bottom: 2rem; padding: 1rem;">
        <h1 style="margin-bottom: 0.5rem;">🎓 NPTEL Agentic RAG System</h1>
        <p style="color: #6b7280; font-size: 1.1rem;">AI-Powered Lecture Assistant</p>
    </div>
    """, unsafe_allow_html=True)


def render_agent_status(container, steps):
    """Render the status of agents based on steps completed"""
    
    agents = ["Planner", "Retriever", "Reasoning", "Validator"]
    completed = [s.get('agent') for s in steps]
    
    with container:
        # st.markdown("##### ⚡ Agent Pipeline Status")
        cols = st.columns(4)
        
        for i, agent in enumerate(agents):
            is_done = agent in completed
            with cols[i]:
                st.markdown(f"""
                <div class="agent-status" style="border-left: 3px solid {'#10b981' if is_done else '#d1d5db'};">
                    <span style="font-size: 1.2rem; margin-right: 0.5rem;">{'✅' if is_done else '⏱️'}</span>
                    <div style="line-height: 1.2;">
                        <strong style="font-size: 0.9rem;">{agent}</strong><br>
                        <small style="color: #6b7280; font-size: 0.75rem;">{'Completed' if is_done else 'Pending'}</small>
                    </div>
                </div>
                """, unsafe_allow_html=True)

def run_pipeline(query: str):
    """Execute the pipeline"""
    try:
        pipeline = create_pipeline()
        return pipeline.execute(query)
    except Exception as e:
        return {
            "status": "FAILED",
            "answer": f"Error: {e}",
            "steps": []
        }

def main():
    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []

    render_header()
    
    # Sidebar
    with st.sidebar:
        st.info("**Lightning Fast Mode** ⚡\n\nOptimized for speed and accuracy.")
        
        if st.button("🗑️ Clear Chat", use_container_width=True):
            st.session_state.messages = []
            st.rerun()

    # Display chat messages from history on app rerun
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if "status_steps" in message:
                 with st.expander("🔍 Pipeline Details", expanded=False):
                     render_agent_status(st.container(), message["status_steps"])
            
            if "sources" in message:
                with st.expander("📚 Retrieved Sources & Videos", expanded=False):
                    for i, chunk in enumerate(message["sources"], 1):
                        meta = chunk.get('metadata', {})
                        
                        # Human readable header
                        course = meta.get('course_name', 'Unknown Course')
                        lec_title = meta.get('lecture_title', 'Unknown Lecture')
                        lec_no = meta.get('lecture_no', '?')
                        week_no = meta.get('week_no', '?')
                        
                        st.markdown(f"**Source {i}: {course}**")
                        st.caption(f"Lecture {lec_no} (Week {week_no}): {lec_title}")
                        
                        # Video Embed
                        video_url = meta.get('video_url')
                        if video_url:
                            try:
                                st.video(video_url)
                            except Exception:
                                st.warning(f"Could not load video: {video_url}")
                        
                        # Content
                        st.markdown("**Transcript Snippet:**")
                        st.info(chunk.get('content', '')[:400] + "...")
                        st.markdown("---")

    # Accept user input
    if prompt := st.chat_input("Ask a question about NPTEL lectures..."):
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        # Display user message in chat message container
        with st.chat_message("user"):
            st.markdown(prompt)

        # Display assistant response in chat message container
        with st.chat_message("assistant"):
            message_placeholder = st.empty()
            
            # Show "Thinking" spinner
            with st.spinner("🤖 Assistant is thinking..."):
                start_time = time.time()
                result = run_pipeline(prompt)
                duration = time.time() - start_time
            
            # Show status
            # st.success(f"Generated in {duration:.2f}s")
            
            if result.get('status') == 'FAILED':
                 response_text = f"❌ **Error**: {result.get('answer')}"
                 message_placeholder.markdown(response_text)
            else:
                 response_text = result.get('answer', 'No answer generated.')
                 message_placeholder.markdown(response_text)
            
            # Save assistant message to history with metadata
            assistant_msg = {
                "role": "assistant",
                "content": response_text,
                "status_steps": result.get('steps', []),
                "sources": result.get('retrieved_chunks', [])
            }
            st.session_state.messages.append(assistant_msg)
            
            # Show sources immediately for current response
            if assistant_msg["status_steps"] or assistant_msg["sources"]:
                col1, col2 = st.columns(2)
                with col1:
                    with st.expander("🔍 Pipeline Details", expanded=False):
                        render_agent_status(st.container(), assistant_msg["status_steps"])
                with col2:
                    with st.expander("📚 Retrieved Sources & Videos", expanded=False):
                         for i, chunk in enumerate(assistant_msg["sources"], 1):
                            meta = chunk.get('metadata', {})
                            
                            # Human readable header
                            course = meta.get('course_name', 'Unknown Course')
                            lec_title = meta.get('lecture_title', 'Unknown Lecture')
                            lec_no = meta.get('lecture_no', '?')
                            week_no = meta.get('week_no', '?')
                            
                            st.markdown(f"**Source {i}: {course}**")
                            st.caption(f"Lecture {lec_no} (Week {week_no}): {lec_title}")
                            
                            # Video Embed
                            video_url = meta.get('video_url')
                            if video_url:
                                try:
                                    st.video(video_url)
                                except Exception:
                                    st.warning(f"Could not load video: {video_url}")
                            
                            # Content
                            st.markdown("**Transcript Snippet:**")
                            st.info(chunk.get('content', '')[:400] + "...")
                            st.markdown("---")

if __name__ == "__main__":
    main()
