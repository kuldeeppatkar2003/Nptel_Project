"""
Mistral LLM Wrapper for NPTEL Smart Assistant
==============================================

Provides a clean interface to Mistral LLM for grounded answer generation.
Supports local deployment via Ollama.

This wrapper ensures:
- Strict grounding in retrieved context
- Minimal hallucination through careful prompting
- Citation-friendly output format
- Token budget management

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import os
import logging
from typing import List, Dict, Optional, Any
from dataclasses import dataclass
from langchain_ollama import ChatOllama
from langchain_groq import ChatGroq
from langchain_core.callbacks import StreamingStdOutCallbackHandler
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


@dataclass
class MistralConfig:
    """Configuration for Mistral LLM"""
    
    # Model selection
    model_name: str = os.getenv("LLM_MODEL", "mistral")  # Ollama model name
    
    # Generation parameters
    temperature: float = float(os.getenv("LLM_TEMPERATURE", "0.1"))  # Low temperature for factual responses
    top_p: float = 0.9
    max_tokens: int = 2048
    
    # Context window
    context_window: int = 8192  # Mistral supports 8K tokens
    num_ctx: int = 8192  # For Ollama
    
    # Quality controls
    repeat_penalty: float = 1.1
    top_k: int = 40


class MistralLLM:
    """
    Wrapper for Mistral LLM with RAG-optimized configuration.
    
    Key Features:
    - Grounded generation (strict adherence to context)
    - Citation-ready output
    - Context window management
    - Streaming support
    
    Usage:
        llm = MistralLLM()
        answer = llm.generate_grounded_response(query, chunks)
    """
    
    def __init__(self, config: Optional[MistralConfig] = None):
        """
        Initialize Mistral LLM wrapper.
        
        Args:
            config: MistralConfig object, uses defaults if None
        """
        self.config = config or MistralConfig()
        self.llm = self._initialize_llm()
        
        logger.info(
            f"Mistral LLM initialized: model={self.config.model_name}, "
            f"temp={self.config.temperature}"
        )
    
    def _initialize_llm(self):
        """Initialize the LLM based on configuration (Ollama or Groq)"""
        
        callbacks = []
        if os.getenv('ENABLE_STREAMING', 'false').lower() == 'true':
            callbacks.append(StreamingStdOutCallbackHandler())
        
        provider = os.getenv("LLM_PROVIDER", "ollama").lower()
        
        if provider == "groq":
            logger.info("Initializing ChatGroq LLM...")
            return ChatGroq(
                model_name=self.config.model_name.replace("groq/", ""),
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                api_key=os.getenv("GROQ_API_KEY"),
                callbacks=callbacks
            )
        else:
            # Default to Ollama
            logger.info("Initializing ChatOllama LLM...")
            return ChatOllama(
                model=self.config.model_name.replace("ollama/", ""),
                temperature=self.config.temperature,
                top_p=self.config.top_p,
                num_ctx=self.config.num_ctx,
                base_url=self.config.base_url,
                callbacks=callbacks
            )
    
    def generate_grounded_response(
        self, 
        query: str, 
        context_chunks: List[Dict[str, Any]],
        max_context_chars: int = 6000
    ) -> str:
        """
        Generate an answer strictly grounded in provided context chunks.
        
        This is the PRIMARY method for answer generation. It ensures:
        - Only information from chunks is used
        - Every claim is citation-ready
        - Graceful handling of insufficient context
        
        Args:
            query: Student's question
            context_chunks: List of dicts with 'content' and 'metadata' keys
            max_context_chars: Maximum characters to include from chunks
        
        Returns:
            Generated answer with inline citation markers
        
        Example:
            >>> chunks = [
            ...     {
            ...         'content': 'FCFS is the simplest scheduling algorithm...',
            ...         'metadata': {'course_name': 'OS', 'lecture_no': 15}
            ...     }
            ... ]
            >>> answer = llm.generate_grounded_response("What is FCFS?", chunks)
        """
        
        # Format context from chunks
        formatted_context = self._format_context_for_llm(
            context_chunks, 
            max_context_chars
        )
        
        # Build grounded prompt
        prompt = self._build_grounded_prompt(query, formatted_context)
        
        # Generate response
        try:
            response = self.llm.invoke(prompt)
            logger.info(f"Generated response for query: {query[:50]}...")
            if hasattr(response, 'content'):
                return response.content
            return str(response)
            
        except Exception as e:
            logger.error(f"LLM generation failed: {e}")
            return self._create_error_response(str(e))
    
    def _format_context_for_llm(
        self, 
        chunks: List[Dict[str, Any]], 
        max_chars: int
    ) -> Dict[str, str]:
        """
        Format retrieved chunks into structured context for the LLM.
        
        Creates two sections:
        1. CONTEXT: The actual lecture content
        2. METADATA: Source information for citations
        
        Args:
            chunks: Retrieved chunks from ChromaDB
            max_chars: Character budget
        
        Returns:
            Dict with 'context' and 'metadata' keys
        """
        context_parts = []
        metadata_parts = []
        total_chars = 0
        
        for i, chunk in enumerate(chunks, 1):
            content = chunk.get('content', '')
            meta = chunk.get('metadata', {})
            
            # Build context section
            chunk_text = f"[SOURCE {i}]\n{content}\n---\n"
            chunk_chars = len(chunk_text)
            
            # Truncate content if it exceeds remaining budget
            remaining_chars = max_chars - total_chars
            if chunk_chars > remaining_chars:
                 # Truncate content to fit
                 # -20 for "...\n---\n" overhead safety
                 safe_limit = max(0, remaining_chars - 20)
                 chunk_text = f"[SOURCE {i}]\n{content[:safe_limit]}...\n---\n"
                 chunk_chars = len(chunk_text)
                 
                 context_parts.append(chunk_text)
                 total_chars += chunk_chars
                 logger.warning(f"Truncated chunk {i} to fit context window")
                 break
            
            context_parts.append(chunk_text)
            total_chars += chunk_chars
            
            # Build metadata section
            meta_str = (
                f"[SOURCE {i}] - {meta.get('course_name', 'N/A')}, "
                f"Week {meta.get('week_no', 'N/A')}, "
                f"Lecture {meta.get('lecture_no', 'N/A')}"
            )
            metadata_parts.append(meta_str)
        
        return {
            'context': '\n'.join(context_parts),
            'metadata': '\n'.join(metadata_parts)
        }
    
    def _build_grounded_prompt(
        self, 
        query: str, 
        formatted_context: Dict[str, str]
    ) -> str:
        """
        Build the complete prompt with grounding instructions.
        
        This prompt structure is CRITICAL for preventing hallucinations.
        
        Args:
            query: User's question
            formatted_context: Dict with context and metadata
        
        Returns:
            Complete prompt string
        """
        
        system_instructions = """You are an NPTEL course teaching assistant. Your goal is to provide clear, structured, and helpful answers to students.

**CORE RULES:**
1. **STRICT GROUNDING**: Use ONLY the provided context. Do NOT use outside knowledge.
2. **NO HALLUCINATION**: If the answer is not in the context, state: "I don't have this information in the provided lectures."
3. **MANDATORY CITATIONS**: Cite sources as [Source X] for every key fact.

**OUTPUT FORMAT (STRICTLY FOLLOW THIS MARKDOWN STRUCTURE):**

### 🎯 Summary
[A concise 2-3 sentence summary of the answer]

### 🔑 Key Points
*   [Point 1] [Source X]
*   [Point 2] [Source Y]
*   [Point 3] [Source Z]

### 📝 Detailed Explanation
[A comprehensive explanation of the topic, breaking it down simply as if teaching a student. Use paragraphs and bullet points for readability.]

### ⚠️ Limitations
[If the context was partial or missing specific details, mention it here. Otherwise, omit this section.]
"""

        prompt = f"""{system_instructions}

**CONTEXT FROM NPTEL LECTURES:**

{formatted_context['context']}

**SOURCE METADATA:**
{formatted_context['metadata']}

**STUDENT QUESTION:**
{query}

**INSTRUCTIONS:**
Answer the student's question using ONLY the provided context. Follow the **OUTPUT FORMAT** strictly. Ensure the tone is professional yet encouraging.

**YOUR RESPONSE:**"""

        return prompt
    
    def _create_error_response(self, error_msg: str) -> str:
        """Create user-friendly error message"""
        return f"""I encountered an error while generating the answer: {error_msg}

Please try:
- Rephrasing your question
- Being more specific about the topic
- Checking if the question is about NPTEL course content

If the issue persists, please contact support."""
    
    def estimate_tokens(self, text: str) -> int:
        """
        Rough token estimation (assuming ~4 chars per token for Mistral).
        
        Args:
            text: Input text
        
        Returns:
            Estimated token count
        """
        return len(text) // 4
    
    def fits_in_context(self, text: str) -> bool:
        """
        Check if text fits in context window.
        
        Args:
            text: Text to check
        
        Returns:
            True if text fits, False otherwise
        """
        estimated_tokens = self.estimate_tokens(text)
        return estimated_tokens <= self.config.context_window
    
    def invoke(self, prompt: str) -> str:
        """
        Direct invocation of LLM (for custom use cases).
        
        Args:
            prompt: Complete prompt
        
        Returns:
            Generated text
        """
        try:
            return self.llm.invoke(prompt)
        except Exception as e:
            logger.error(f"LLM invocation failed: {e}")
            raise


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_mistral_llm(
    model_name: str = "mistral",
    temperature: float = 0.1,
    **kwargs
) -> MistralLLM:
    """
    Convenience function to create MistralLLM instance.
    
    Args:
        model_name: Ollama model name
        temperature: Generation temperature
        **kwargs: Additional config parameters
    
    Returns:
        Configured MistralLLM instance
    
    Example:
        >>> llm = create_mistral_llm(model_name="mistral", temperature=0.1)
    """
    
    config_dict = {
        'model_name': model_name,
        'temperature': temperature,
    }
    config_dict.update(kwargs)
    
    config = MistralConfig(**config_dict)
    return MistralLLM(config)


if __name__ == "__main__":
    # Basic test
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Mistral LLM wrapper...")
    
    # Create LLM instance
    llm = create_mistral_llm(model_name="mistral")
    
    # Test chunks
    test_chunks = [
        {
            'content': "FCFS (First-Come-First-Served) is the simplest CPU scheduling algorithm. "
                      "Processes are executed in the order they arrive in the ready queue.",
            'metadata': {
                'course_name': 'Operating Systems',
                'lecture_no': 15,
                'week_no': 5
            }
        }
    ]
    
    # Test query
    test_query = "What is FCFS scheduling?"
    
    try:
        answer = llm.generate_grounded_response(test_query, test_chunks)
        print(f"\nQuery: {test_query}")
        print(f"\nAnswer:\n{answer}")
        print("\n✓ Mistral LLM wrapper test passed!")
    except Exception as e:
        print(f"Error: {e}")