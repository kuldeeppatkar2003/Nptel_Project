"""
Context Manager for NPTEL Agentic RAG System
=============================================

Manages context windows, token budgets, and chunk selection for LLM input.
Ensures retrieved content fits within Mistral's 8K token limit while
maximizing information quality.

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class ContextConfig:
    """Configuration for context management"""
    
    # Token limits
    max_tokens: int = 6000  # Conservative limit for Mistral (8K total)
    chars_per_token: int = 4  # Rough estimate for token calculation
    
    # Selection strategy
    selection_strategy: str = "hybrid"  # hybrid, similarity, diversity
    diversity_threshold: float = 0.85  # Similarity threshold for diversity
    
    # Chunk limits
    min_chunks: int = 1
    max_chunks: int = 15
    
    # Quality thresholds
    min_similarity: float = 0.3  # Drop chunks below this


class ContextManager:
    """
    Manages context window for LLM input.
    
    Responsibilities:
    - Select most relevant chunks within token budget
    - Apply diversity filtering (avoid redundant chunks)
    - Rank chunks by relevance
    - Format chunks for LLM consumption
    
    Usage:
        manager = ContextManager()
        selected = manager.select_chunks(chunks, query, max_tokens=6000)
    """
    
    def __init__(self, config: Optional[ContextConfig] = None):
        """
        Initialize context manager.
        
        Args:
            config: ContextConfig object, uses defaults if None
        """
        self.config = config or ContextConfig()
        logger.info(f"ContextManager initialized: max_tokens={self.config.max_tokens}")
    
    def select_chunks(
        self,
        chunks: List[Dict[str, Any]],
        query: str,
        max_tokens: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Select chunks that fit within token budget while maximizing quality.
        
        Args:
            chunks: Retrieved chunks from ChromaDB
            query: Original user query
            max_tokens: Override default max tokens
        
        Returns:
            List of selected chunks
        """
        if not chunks:
            logger.warning("No chunks provided for selection")
            return []
        
        budget = max_tokens or self.config.max_tokens
        
        # Step 1: Filter by minimum similarity
        filtered = self._filter_by_similarity(chunks)
        logger.info(f"Filtered {len(chunks)} → {len(filtered)} chunks by similarity")
        
        # Step 2: Apply selection strategy
        if self.config.selection_strategy == "hybrid":
            selected = self._hybrid_selection(filtered, budget)
        elif self.config.selection_strategy == "similarity":
            selected = self._similarity_selection(filtered, budget)
        elif self.config.selection_strategy == "diversity":
            selected = self._diversity_selection(filtered, budget)
        else:
            raise ValueError(f"Unknown strategy: {self.config.selection_strategy}")
        
        logger.info(f"Selected {len(selected)} chunks within {budget} token budget")
        
        return selected
    
    def _filter_by_similarity(
        self, 
        chunks: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Filter out chunks below minimum similarity threshold"""
        
        return [
            chunk for chunk in chunks
            if chunk.get('metadata', {}).get('similarity_score', 0) >= self.config.min_similarity
        ]
    
    def _hybrid_selection(
        self,
        chunks: List[Dict[str, Any]],
        budget: int
    ) -> List[Dict[str, Any]]:
        """
        Hybrid selection: balance similarity and diversity.
        
        Algorithm:
        1. Sort by similarity (descending)
        2. Iteratively add chunks that fit budget
        3. Skip chunks too similar to already selected ones
        """
        selected = []
        total_tokens = 0
        
        # Sort by similarity
        sorted_chunks = sorted(
            chunks,
            key=lambda x: x.get('metadata', {}).get('similarity_score', 0),
            reverse=True
        )
        
        for chunk in sorted_chunks:
            # Check token budget
            chunk_tokens = self.estimate_tokens(chunk.get('content', ''))
            
            if total_tokens + chunk_tokens > budget:
                logger.debug(f"Stopping selection: budget exceeded")
                break
            
            # Check diversity (if we have selected chunks)
            if selected and not self._is_diverse(chunk, selected):
                logger.debug(f"Skipping chunk: too similar to existing selections")
                continue
            
            # Add chunk
            selected.append(chunk)
            total_tokens += chunk_tokens
            
            # Check if we hit max chunks
            if len(selected) >= self.config.max_chunks:
                logger.debug(f"Stopping selection: max chunks reached")
                break
        
        return selected
    
    def _similarity_selection(
        self,
        chunks: List[Dict[str, Any]],
        budget: int
    ) -> List[Dict[str, Any]]:
        """
        Pure similarity-based selection (greedy).
        
        Simply take top-k chunks by similarity until budget is exhausted.
        """
        selected = []
        total_tokens = 0
        
        # Sort by similarity
        sorted_chunks = sorted(
            chunks,
            key=lambda x: x.get('metadata', {}).get('similarity_score', 0),
            reverse=True
        )
        
        for chunk in sorted_chunks:
            chunk_tokens = self.estimate_tokens(chunk.get('content', ''))
            
            if total_tokens + chunk_tokens > budget:
                break
            
            selected.append(chunk)
            total_tokens += chunk_tokens
            
            if len(selected) >= self.config.max_chunks:
                break
        
        return selected
    
    def _diversity_selection(
        self,
        chunks: List[Dict[str, Any]],
        budget: int
    ) -> List[Dict[str, Any]]:
        """
        Diversity-focused selection.
        
        Prioritize chunks from different sources/lectures.
        """
        selected = []
        total_tokens = 0
        seen_sources = set()
        
        # Sort by similarity first
        sorted_chunks = sorted(
            chunks,
            key=lambda x: x.get('metadata', {}).get('similarity_score', 0),
            reverse=True
        )
        
        for chunk in sorted_chunks:
            # Create source signature
            meta = chunk.get('metadata', {})
            source_sig = f"{meta.get('course_name')}_{meta.get('lecture_no')}"
            
            # Skip if we already have content from this source
            if source_sig in seen_sources:
                continue
            
            # Check budget
            chunk_tokens = self.estimate_tokens(chunk.get('content', ''))
            if total_tokens + chunk_tokens > budget:
                break
            
            # Add chunk
            selected.append(chunk)
            total_tokens += chunk_tokens
            seen_sources.add(source_sig)
            
            if len(selected) >= self.config.max_chunks:
                break
        
        return selected
    
    def _is_diverse(
        self,
        chunk: Dict[str, Any],
        selected: List[Dict[str, Any]]
    ) -> bool:
        """
        Check if chunk is sufficiently different from already selected chunks.
        
        Args:
            chunk: Candidate chunk
            selected: Already selected chunks
        
        Returns:
            True if chunk is diverse enough, False otherwise
        """
        # Simple diversity check based on content similarity
        # In production, you'd use embeddings for this
        
        chunk_content = chunk.get('content', '').lower()
        
        for sel_chunk in selected:
            sel_content = sel_chunk.get('content', '').lower()
            
            # Simple overlap ratio
            overlap = self._compute_overlap(chunk_content, sel_content)
            
            if overlap > self.config.diversity_threshold:
                return False  # Too similar
        
        return True  # Sufficiently diverse
    
    def _compute_overlap(self, text1: str, text2: str) -> float:
        """
        Compute simple word-level overlap between two texts.
        
        Args:
            text1: First text
            text2: Second text
        
        Returns:
            Overlap ratio (0-1)
        """
        words1 = set(text1.split())
        words2 = set(text2.split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1.intersection(words2)
        union = words1.union(words2)
        
        return len(intersection) / len(union)
    
    def estimate_tokens(self, text: str) -> int:
        """
        Estimate token count for text.
        
        Args:
            text: Input text
        
        Returns:
            Estimated token count
        """
        return len(text) // self.config.chars_per_token
    
    def fits_in_budget(self, chunks: List[Dict[str, Any]], budget: int) -> bool:
        """
        Check if all chunks fit within token budget.
        
        Args:
            chunks: List of chunks
            budget: Token budget
        
        Returns:
            True if all chunks fit, False otherwise
        """
        total_tokens = sum(
            self.estimate_tokens(chunk.get('content', ''))
            for chunk in chunks
        )
        return total_tokens <= budget
    
    def compress_chunks(
        self,
        chunks: List[Dict[str, Any]],
        target_tokens: int
    ) -> List[Dict[str, Any]]:
        """
        Compress chunks by truncating content to fit target token count.
        
        This is a fallback strategy when selection alone isn't enough.
        
        Args:
            chunks: Input chunks
            target_tokens: Target token count
        
        Returns:
            Compressed chunks
        """
        compressed = []
        tokens_per_chunk = target_tokens // len(chunks) if chunks else 0
        chars_per_chunk = tokens_per_chunk * self.config.chars_per_token
        
        for chunk in chunks:
            content = chunk.get('content', '')
            
            if len(content) > chars_per_chunk:
                # Truncate with ellipsis
                truncated = content[:chars_per_chunk - 3] + "..."
                chunk_copy = chunk.copy()
                chunk_copy['content'] = truncated
                chunk_copy['compressed'] = True
                compressed.append(chunk_copy)
            else:
                compressed.append(chunk)
        
        logger.warning(f"Compressed {len(chunks)} chunks to fit {target_tokens} tokens")
        return compressed
    
    def get_context_stats(self, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Get statistics about selected chunks.
        
        Args:
            chunks: Selected chunks
        
        Returns:
            Dict with statistics
        """
        if not chunks:
            return {
                'num_chunks': 0,
                'total_tokens': 0,
                'unique_sources': 0
            }
        
        total_tokens = sum(
            self.estimate_tokens(chunk.get('content', ''))
            for chunk in chunks
        )
        
        unique_sources = len(set(
            f"{chunk.get('metadata', {}).get('course_name')}_{chunk.get('metadata', {}).get('lecture_no')}"
            for chunk in chunks
        ))
        
        avg_similarity = np.mean([
            chunk.get('metadata', {}).get('similarity_score', 0)
            for chunk in chunks
        ])
        
        return {
            'num_chunks': len(chunks),
            'total_tokens': total_tokens,
            'unique_sources': unique_sources,
            'avg_similarity': round(avg_similarity, 3),
            'token_budget_used': round(total_tokens / self.config.max_tokens * 100, 1)
        }


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_context_manager(
    max_tokens: int = 6000,
    selection_strategy: str = "hybrid"
) -> ContextManager:
    """
    Create a ContextManager with custom settings.
    
    Args:
        max_tokens: Maximum token budget
        selection_strategy: Selection strategy (hybrid, similarity, diversity)
    
    Returns:
        Configured ContextManager
    """
    config = ContextConfig(
        max_tokens=max_tokens,
        selection_strategy=selection_strategy
    )
    return ContextManager(config)


if __name__ == "__main__":
    # Test context manager
    logging.basicConfig(level=logging.INFO)
    
    print("Testing ContextManager...")
    
    # Create manager
    manager = create_context_manager(max_tokens=1000)
    
    # Test chunks
    test_chunks = [
        {
            'content': 'A' * 500,  # ~125 tokens
            'metadata': {'similarity_score': 0.9, 'course_name': 'OS', 'lecture_no': 1}
        },
        {
            'content': 'B' * 500,
            'metadata': {'similarity_score': 0.8, 'course_name': 'OS', 'lecture_no': 2}
        },
        {
            'content': 'C' * 500,
            'metadata': {'similarity_score': 0.7, 'course_name': 'OS', 'lecture_no': 3}
        },
        {
            'content': 'D' * 500,
            'metadata': {'similarity_score': 0.6, 'course_name': 'OS', 'lecture_no': 4}
        }
    ]
    
    # Test selection
    selected = manager.select_chunks(test_chunks, "test query", max_tokens=1000)
    
    print(f"\nSelected {len(selected)} chunks")
    
    # Get stats
    stats = manager.get_context_stats(selected)
    print(f"Context stats: {stats}")
    
    print("\n✓ ContextManager test passed!")
