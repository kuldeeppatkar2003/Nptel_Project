"""
LLM Module for NPTEL Agentic RAG System
========================================

This module provides LLM integration for answer generation.

Components:
- MistralLLM: Main LLM wrapper for Mistral via Ollama
- ContextManager: Manages context window and token budgets
- Prompts: Centralized prompt templates

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

from .mistral_wrapper import MistralLLM, MistralConfig, create_mistral_llm
from .context_manager import ContextManager, ContextConfig
from .prompts import (
    PLANNER_SYSTEM_PROMPT,
    RETRIEVER_SYSTEM_PROMPT,
    REASONING_SYSTEM_PROMPT,
    VALIDATOR_SYSTEM_PROMPT,
    format_planning_prompt,
    format_retrieval_prompt,
    format_reasoning_prompt,
    format_validation_prompt,
    format_grounded_generation,
    get_prompt,
    PROMPT_REGISTRY
)

__all__ = [
    # Main LLM
    'MistralLLM',
    'MistralConfig',
    'create_mistral_llm',
    
    # Context Management
    'ContextManager',
    'ContextConfig',
    
    # System Prompts
    'PLANNER_SYSTEM_PROMPT',
    'RETRIEVER_SYSTEM_PROMPT',
    'REASONING_SYSTEM_PROMPT',
    'VALIDATOR_SYSTEM_PROMPT',
    
    # Prompt Formatters
    'format_planning_prompt',
    'format_retrieval_prompt',
    'format_reasoning_prompt',
    'format_validation_prompt',
    'format_grounded_generation',
    'get_prompt',
    'PROMPT_REGISTRY'
]

__version__ = '1.0.0'