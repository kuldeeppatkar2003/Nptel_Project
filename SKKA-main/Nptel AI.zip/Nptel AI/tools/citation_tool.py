"""
Citation Tool for NPTEL Agentic RAG System
===========================================

Formats citations and enhances answers with clickable source links.
Converts [Source X] markers to proper markdown links with PDFs/videos.

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
import json
import re
from typing import Dict, List, Any, Optional, Tuple

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


# ============================================================================
# TOOL INPUT SCHEMAS
# ============================================================================

class CitationFormattingInput(BaseModel):
    """Input schema for citation formatting"""
    
    answer: str = Field(
        ...,
        description="Answer text with [Source X] markers"
    )
    source_metadata_json: str = Field(
        ...,
        description="JSON with source metadata (URLs, titles)"
    )


class SourceMaterialsInput(BaseModel):
    """Input schema for creating source materials section"""
    
    sources_json: str = Field(
        ...,
        description="JSON array of sources with metadata"
    )


# ============================================================================
# CITATION FORMATTING TOOL
# ============================================================================

class CitationTool(BaseTool):
    """
    Citation Formatting Tool.
    
    Enhances answers by converting [Source X] markers to clickable
    markdown links with lecture titles, PDF URLs, and video URLs.
    
    Usage by agents:
        enhanced = citation_tool.run(
            answer=basic_answer,
            source_metadata_json=sources_json
        )
    """
    
    name: str = "format_citations"
    description: str = """Convert [Source X] citations to clickable links.
    
Takes an answer with basic [Source X] markers and enhances them with:
- Clickable markdown links to PDFs
- Lecture titles
- Video URLs
- Course information

Also adds a "Source Materials" section at the end with all references."""
    
    args_schema: type[BaseModel] = CitationFormattingInput
    
    def _run(
        self,
        answer: str,
        source_metadata_json: str
    ) -> str:
        """
        Format citations in answer.
        
        Args:
            answer: Answer with [Source X] markers
            source_metadata_json: JSON with source metadata
        
        Returns:
            Enhanced answer with clickable citations
        """
        
        try:
            # Parse source metadata
            sources = json.loads(source_metadata_json)
            
            # Build source lookup
            source_map = {}
            if isinstance(sources, dict) and 'chunks' in sources:
                # Format from retrieval output
                for chunk in sources['chunks']:
                    chunk_id = chunk.get('chunk_id')
                    source_map[chunk_id] = chunk.get('metadata', {})
            elif isinstance(sources, list):
                # Direct list format
                for i, source in enumerate(sources, 1):
                    source_map[i] = source
            
            # Enhance answer
            enhanced_answer = self._enhance_citations(answer, source_map)
            
            # Add source materials section
            source_section = self._create_source_section(source_map)
            
            final_answer = f"{enhanced_answer}\n\n{source_section}"
            
            logger.info(f"Enhanced {len(source_map)} citations in answer")
            
            return final_answer
            
        except Exception as e:
            logger.error(f"Citation formatting failed: {e}")
            # Return original answer if formatting fails
            return answer
    
    def _enhance_citations(
        self,
        answer: str,
        source_map: Dict[int, Dict[str, Any]]
    ) -> str:
        """
        Replace [Source X] with formatted citations.
        
        Args:
            answer: Original answer
            source_map: Mapping of source IDs to metadata
        
        Returns:
            Answer with enhanced citations
        """
        
        def replace_citation(match):
            source_num = int(match.group(1))
            
            if source_num not in source_map:
                return match.group(0)  # Keep original if no metadata
            
            meta = source_map[source_num]
            
            # Extract info
            course = meta.get('course_name', 'N/A')
            lecture_no = meta.get('lecture_no', 'N/A')
            lecture_title = meta.get('lecture_title', f'Lecture {lecture_no}')
            pdf_url = meta.get('pdf_url', '')
            
            # Format citation
            if pdf_url:
                citation = f"[Source {source_num} - {course}, {lecture_title}]({pdf_url})"
            else:
                citation = f"[Source {source_num} - {course}, {lecture_title}]"
            
            return citation
        
        # Replace all [Source X] patterns
        pattern = r'\[Source (\d+)\]'
        enhanced = re.sub(pattern, replace_citation, answer)
        
        return enhanced
    
    def _create_source_section(
        self,
        source_map: Dict[int, Dict[str, Any]]
    ) -> str:
        """
        Create "Source Materials" section.
        
        Args:
            source_map: Source metadata
        
        Returns:
            Formatted source section
        """
        
        if not source_map:
            return ""
        
        section = "---\n\n## 📚 Source Materials\n\n"
        
        for source_id in sorted(source_map.keys()):
            meta = source_map[source_id]
            
            course = meta.get('course_name', 'Unknown Course')
            lecture_no = meta.get('lecture_no', 'N/A')
            week_no = meta.get('week_no', 'N/A')
            lecture_title = meta.get('lecture_title', f'Lecture {lecture_no}')
            pdf_url = meta.get('pdf_url', '')
            video_url = meta.get('video_url', '')
            
            section += f"**Source {source_id}:** {course} - {lecture_title}\n"
            section += f"- Week: {week_no}, Lecture: {lecture_no}\n"
            
            if pdf_url:
                section += f"- [📄 PDF Transcript]({pdf_url})\n"
            if video_url:
                section += f"- [🎥 Video Lecture]({video_url})\n"
            
            section += "\n"
        
        return section


# ============================================================================
# SOURCE MATERIALS TOOL
# ============================================================================

class SourceMaterialsTool(BaseTool):
    """Tool for creating source materials section only"""
    
    name: str = "create_source_materials"
    description: str = """Create a formatted "Source Materials" section.
    
Takes source metadata and creates a markdown section listing all
sources with links to PDFs and videos."""
    
    args_schema: type[BaseModel] = SourceMaterialsInput
    
    def _run(self, sources_json: str) -> str:
        """
        Create source materials section.
        
        Args:
            sources_json: JSON with sources
        
        Returns:
            Formatted markdown section
        """
        
        try:
            sources = json.loads(sources_json)
            
            section = "---\n\n## 📚 Source Materials\n\n"
            
            if isinstance(sources, list):
                for i, source in enumerate(sources, 1):
                    section += self._format_source_item(i, source)
            
            return section
            
        except Exception as e:
            logger.error(f"Failed to create source section: {e}")
            return ""
    
    def _format_source_item(
        self,
        index: int,
        source: Dict[str, Any]
    ) -> str:
        """Format a single source item"""
        
        course = source.get('course_name', 'Unknown')
        title = source.get('lecture_title', f"Lecture {source.get('lecture_no', 'N/A')}")
        pdf = source.get('pdf_url', '')
        video = source.get('video_url', '')
        
        item = f"**Source {index}:** {course} - {title}\n"
        
        if pdf:
            item += f"- [📄 PDF]({pdf})\n"
        if video:
            item += f"- [🎥 Video]({video})\n"
        
        item += "\n"
        
        return item


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_citation_tool() -> CitationTool:
    """
    Create citation formatting tool.
    
    Returns:
        Configured CitationTool
    """
    return CitationTool()


def format_citation(
    answer: str,
    sources: List[Dict[str, Any]]
) -> str:
    """
    Format citations (direct function for non-agent use).
    
    Args:
        answer: Answer with [Source X] markers
        sources: List of source metadata dicts
    
    Returns:
        Enhanced answer with clickable citations
    """
    tool = CitationTool()
    
    # Convert sources to JSON
    sources_json = json.dumps(sources)
    
    return tool._run(
        answer=answer,
        source_metadata_json=sources_json
    )


def enhance_answer_with_links(
    answer: str,
    source_map: Dict[int, Dict[str, Any]]
) -> str:
    """
    Enhance answer with clickable source links.
    
    Args:
        answer: Original answer
        source_map: Mapping of source IDs to metadata
    
    Returns:
        Enhanced answer
    """
    tool = CitationTool()
    return tool._enhance_citations(answer, source_map)


def create_source_materials_section(
    sources: List[Dict[str, Any]]
) -> str:
    """
    Create source materials section.
    
    Args:
        sources: List of source metadata
    
    Returns:
        Formatted markdown section
    """
    tool = SourceMaterialsTool()
    sources_json = json.dumps(sources)
    return tool._run(sources_json=sources_json)


# ============================================================================
# CITATION EXTRACTION
# ============================================================================

def extract_citations(answer: str) -> List[int]:
    """
    Extract all [Source X] citations from answer.
    
    Args:
        answer: Answer text
    
    Returns:
        List of unique source IDs
    """
    pattern = r'\[Source (\d+)\]'
    matches = re.findall(pattern, answer)
    return sorted(set(int(m) for m in matches))


def count_citations(answer: str) -> int:
    """
    Count total citations in answer.
    
    Args:
        answer: Answer text
    
    Returns:
        Number of [Source X] citations
    """
    pattern = r'\[Source \d+\]'
    return len(re.findall(pattern, answer))


def has_citations(answer: str) -> bool:
    """
    Check if answer has any citations.
    
    Args:
        answer: Answer text
    
    Returns:
        True if citations found, False otherwise
    """
    return count_citations(answer) > 0


# ============================================================================
# DEFAULT TOOL INSTANCES
# ============================================================================

default_citation_tool = create_citation_tool()
default_source_tool = SourceMaterialsTool()


if __name__ == "__main__":
    # Test the tool
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Citation Tool...")
    
    # Create tool
    tool = create_citation_tool()
    
    # Test data
    test_answer = """FCFS is the simplest scheduling algorithm [Source 1].
It executes processes in arrival order [Source 1].
SJF is more optimal but requires prediction [Source 2]."""
    
    test_sources = json.dumps({
        "chunks": [
            {
                "chunk_id": 1,
                "metadata": {
                    "course_name": "Operating Systems",
                    "lecture_no": 15,
                    "week_no": 5,
                    "lecture_title": "CPU Scheduling - Part 1",
                    "pdf_url": "https://example.com/lec15.pdf",
                    "video_url": "https://example.com/lec15"
                }
            },
            {
                "chunk_id": 2,
                "metadata": {
                    "course_name": "Operating Systems",
                    "lecture_no": 16,
                    "lecture_title": "CPU Scheduling - Part 2",
                    "pdf_url": "https://example.com/lec16.pdf",
                    "video_url": "https://example.com/lec16"
                }
            }
        ]
    })
    
    # Test formatting
    print("\nTest 1: Citation formatting")
    enhanced = tool._run(
        answer=test_answer,
        source_metadata_json=test_sources
    )
    
    print(f"  Enhanced answer length: {len(enhanced)} chars")
    print(f"  Has source section: {'Source Materials' in enhanced}")
    
    # Test extraction
    print("\nTest 2: Citation extraction")
    citations = extract_citations(test_answer)
    print(f"  Unique citations: {citations}")
    print(f"  Total count: {count_citations(test_answer)}")
    print(f"  Has citations: {has_citations(test_answer)}")
    
    print("\n✓ Citation Tool tests passed!")
