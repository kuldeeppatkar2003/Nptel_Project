"""
Validation Tool for NPTEL Agentic RAG System
=============================================

Validates answers against source chunks to detect hallucinations
and verify citation completeness.

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
import json
import re
from typing import Dict, List, Any, Tuple, Optional

from crewai.tools import BaseTool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


# ============================================================================
# TOOL INPUT SCHEMAS
# ============================================================================

class ClaimVerificationInput(BaseModel):
    """Input schema for claim verification"""
    
    claim: str = Field(
        ...,
        description="Factual claim to verify"
    )
    chunks_json: str = Field(
        ...,
        description="JSON with source chunks"
    )


class HallucinationDetectionInput(BaseModel):
    """Input schema for hallucination detection"""
    
    answer: str = Field(
        ...,
        description="Generated answer to check"
    )
    chunks_json: str = Field(
        ...,
        description="JSON with source chunks used"
    )


class CitationCoverageInput(BaseModel):
    """Input schema for citation coverage check"""
    
    answer: str = Field(
        ...,
        description="Answer with citations"
    )


# ============================================================================
# CLAIM VERIFICATION TOOL
# ============================================================================

class ValidationTool(BaseTool):
    """
    Answer Validation Tool.
    
    Verifies that claims in generated answers are supported by
    source chunks. Detects potential hallucinations.
    
    Usage by agents:
        verification = validation_tool.run(
            claim="FCFS is the simplest algorithm",
            chunks_json=source_chunks
        )
    """
    
    name: str = "verify_claim"
    description: str = """Verify if a claim is supported by source chunks.
    
Checks if a factual claim appears in the provided source chunks.
Returns verification status and supporting evidence if found.

Use this to validate each claim before including in final answer."""
    
    args_schema: type[BaseModel] = ClaimVerificationInput
    
    def _run(
        self,
        claim: str,
        chunks_json: str
    ) -> str:
        """
        Verify claim against chunks.
        
        Args:
            claim: Claim to verify
            chunks_json: JSON with source chunks
        
        Returns:
            JSON with verification results
        """
        
        try:
            # Parse chunks
            data = json.loads(chunks_json)
            chunks = data.get('chunks', [])
            
            if not chunks:
                return json.dumps({
                    "verified": False,
                    "reason": "No source chunks provided",
                    "supporting_chunk": None
                })
            
            # Check each chunk
            claim_lower = claim.lower()
            
            for i, chunk in enumerate(chunks, 1):
                content = chunk.get('content', '').lower()
                
                # Simple substring match (can be enhanced with semantic similarity)
                if self._is_claim_supported(claim_lower, content):
                    return json.dumps({
                        "verified": True,
                        "supporting_chunk_id": i,
                        "chunk_excerpt": chunk.get('content', '')[:200] + "...",
                        "source": chunk.get('metadata', {})
                    }, indent=2)
            
            return json.dumps({
                "verified": False,
                "reason": "Claim not found in any source chunk",
                "suggestion": "Remove or rephrase this claim"
            }, indent=2)
            
        except Exception as e:
            logger.error(f"Claim verification failed: {e}")
            return json.dumps({
                "verified": False,
                "error": str(e)
            })
    
    def _is_claim_supported(
        self,
        claim: str,
        content: str
    ) -> bool:
        """
        Check if claim is supported by content.
        
        Uses simple keyword matching. Can be enhanced with:
        - Semantic similarity (embeddings)
        - Entity extraction
        - Dependency parsing
        
        Args:
            claim: Claim text (lowercase)
            content: Source content (lowercase)
        
        Returns:
            True if supported, False otherwise
        """
        
        # Extract key terms from claim (simple approach)
        # Remove common words
        stop_words = {
            'is', 'are', 'was', 'were', 'the', 'a', 'an', 'and', 'or',
            'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with'
        }
        
        claim_words = set(claim.split()) - stop_words
        content_words = set(content.split())
        
        # Check if most claim words appear in content
        overlap = claim_words.intersection(content_words)
        overlap_ratio = len(overlap) / len(claim_words) if claim_words else 0
        
        # Require at least 60% word overlap
        return overlap_ratio >= 0.6


# ============================================================================
# HALLUCINATION DETECTION TOOL
# ============================================================================

class HallucinationDetectionTool(BaseTool):
    """Tool for detecting hallucinations in answers"""
    
    name: str = "detect_hallucinations"
    description: str = """Detect potential hallucinations in generated answer.
    
Analyzes the answer and identifies statements that are NOT supported
by the source chunks. Returns list of suspicious claims.

Use this as a final check before approving an answer."""
    
    args_schema: type[BaseModel] = HallucinationDetectionInput
    
    def _run(
        self,
        answer: str,
        chunks_json: str
    ) -> str:
        """
        Detect hallucinations.
        
        Args:
            answer: Generated answer
            chunks_json: Source chunks
        
        Returns:
            JSON with detection results
        """
        
        try:
            # Parse chunks
            data = json.loads(chunks_json)
            chunks = data.get('chunks', [])
            
            # Extract sentences from answer
            sentences = self._extract_sentences(answer)
            
            # Check each sentence
            unsupported = []
            supported = []
            
            for sentence in sentences:
                # Skip very short sentences or citations
                if len(sentence.split()) < 4 or sentence.startswith('[Source'):
                    continue
                
                # Check if supported by any chunk
                is_supported = False
                for chunk in chunks:
                    content = chunk.get('content', '')
                    if self._sentence_in_content(sentence, content):
                        is_supported = True
                        supported.append(sentence)
                        break
                
                if not is_supported:
                    unsupported.append(sentence)
            
            # Calculate hallucination risk
            total_claims = len(supported) + len(unsupported)
            hallucination_ratio = len(unsupported) / total_claims if total_claims > 0 else 0
            
            if hallucination_ratio > 0.3:
                risk = "HIGH"
            elif hallucination_ratio > 0.1:
                risk = "MEDIUM"
            else:
                risk = "LOW"
            
            result = {
                "hallucination_risk": risk,
                "total_claims_checked": total_claims,
                "supported_claims": len(supported),
                "unsupported_claims": len(unsupported),
                "suspicious_statements": unsupported[:5],  # Top 5
                "hallucination_ratio": round(hallucination_ratio, 2)
            }
            
            logger.info(
                f"Hallucination check: {len(unsupported)}/{total_claims} "
                f"unsupported claims (risk: {risk})"
            )
            
            return json.dumps(result, indent=2)
            
        except Exception as e:
            logger.error(f"Hallucination detection failed: {e}")
            return json.dumps({
                "hallucination_risk": "UNKNOWN",
                "error": str(e)
            })
    
    def _extract_sentences(self, text: str) -> List[str]:
        """
        Extract sentences from text.
        
        Args:
            text: Input text
        
        Returns:
            List of sentences
        """
        # Simple sentence splitting (can be improved with NLTK)
        sentences = re.split(r'[.!?]+', text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _sentence_in_content(
        self,
        sentence: str,
        content: str
    ) -> bool:
        """
        Check if sentence is supported by content.
        
        Args:
            sentence: Sentence to check
            content: Source content
        
        Returns:
            True if supported
        """
        sentence_lower = sentence.lower()
        content_lower = content.lower()
        
        # Extract key words
        words = set(sentence_lower.split()) - {
            'is', 'are', 'was', 'were', 'the', 'a', 'an', 'and', 'or', 'but'
        }
        
        # Check overlap
        content_words = set(content_lower.split())
        overlap = words.intersection(content_words)
        
        return len(overlap) / len(words) >= 0.5 if words else False


# ============================================================================
# CITATION COVERAGE TOOL
# ============================================================================

class CitationCoverageTool(BaseTool):
    """Tool for checking citation coverage"""
    
    name: str = "check_citation_coverage"
    description: str = """Check if answer has proper citation coverage.
    
Analyzes the answer to ensure:
- All factual claims have citations
- Citation format is correct
- No citation gaps

Returns coverage percentage and missing citations."""
    
    args_schema: type[BaseModel] = CitationCoverageInput
    
    def _run(self, answer: str) -> str:
        """
        Check citation coverage.
        
        Args:
            answer: Answer to check
        
        Returns:
            JSON with coverage report
        """
        
        try:
            # Extract sentences
            sentences = self._extract_factual_sentences(answer)
            
            # Count citations
            citations = re.findall(r'\[Source \d+\]', answer)
            
            # Simple heuristic: each factual sentence should have ~1 citation
            expected_citations = len(sentences)
            actual_citations = len(citations)
            
            coverage = min(actual_citations / expected_citations, 1.0) if expected_citations > 0 else 0
            coverage_pct = round(coverage * 100, 1)
            
            # Determine status
            if coverage >= 0.9:
                status = "EXCELLENT"
            elif coverage >= 0.7:
                status = "GOOD"
            elif coverage >= 0.5:
                status = "FAIR"
            else:
                status = "POOR"
            
            result = {
                "citation_coverage": f"{coverage_pct}%",
                "status": status,
                "factual_sentences": len(sentences),
                "total_citations": len(citations),
                "unique_sources": len(set(citations)),
                "needs_improvement": coverage < 0.7
            }
            
            logger.info(f"Citation coverage: {coverage_pct}% ({status})")
            
            return json.dumps(result, indent=2)
            
        except Exception as e:
            logger.error(f"Citation coverage check failed: {e}")
            return json.dumps({
                "citation_coverage": "0%",
                "error": str(e)
            })
    
    def _extract_factual_sentences(self, text: str) -> List[str]:
        """Extract sentences that likely contain factual claims"""
        
        sentences = re.split(r'[.!?]+', text)
        
        # Filter out very short sentences and questions
        factual = []
        for s in sentences:
            s = s.strip()
            if len(s.split()) >= 4 and not s.endswith('?'):
                factual.append(s)
        
        return factual


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_validation_tool() -> ValidationTool:
    """Create validation tool"""
    return ValidationTool()


def verify_claim_in_chunks(
    claim: str,
    chunks: List[Dict[str, Any]]
) -> bool:
    """
    Verify if claim is supported (direct function).
    
    Args:
        claim: Claim to verify
        chunks: Source chunks
    
    Returns:
        True if verified, False otherwise
    """
    tool = ValidationTool()
    chunks_json = json.dumps({"chunks": chunks})
    
    result_json = tool._run(claim=claim, chunks_json=chunks_json)
    result = json.loads(result_json)
    
    return result.get('verified', False)


def detect_hallucinations(
    answer: str,
    chunks: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Detect hallucinations (direct function).
    
    Args:
        answer: Generated answer
        chunks: Source chunks
    
    Returns:
        Dict with detection results
    """
    tool = HallucinationDetectionTool()
    chunks_json = json.dumps({"chunks": chunks})
    
    result_json = tool._run(answer=answer, chunks_json=chunks_json)
    return json.loads(result_json)


def calculate_citation_coverage(answer: str) -> float:
    """
    Calculate citation coverage (direct function).
    
    Args:
        answer: Answer to check
    
    Returns:
        Coverage ratio (0-1)
    """
    tool = CitationCoverageTool()
    result_json = tool._run(answer=answer)
    result = json.loads(result_json)
    
    coverage_str = result.get('citation_coverage', '0%')
    return float(coverage_str.rstrip('%')) / 100


# ============================================================================
# DEFAULT TOOL INSTANCES
# ============================================================================

default_validation_tool = create_validation_tool()
default_hallucination_tool = HallucinationDetectionTool()
default_coverage_tool = CitationCoverageTool()


if __name__ == "__main__":
    # Test the tools
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Validation Tool...")
    
    # Test data
    test_chunks = json.dumps({
        "chunks": [
            {
                "content": "FCFS is the simplest CPU scheduling algorithm. It executes processes in arrival order.",
                "metadata": {"course_name": "OS", "lecture_no": 15}
            }
        ]
    })
    
    # Test 1: Claim verification
    print("\nTest 1: Claim verification")
    tool = ValidationTool()
    
    result = tool._run(
        claim="FCFS is the simplest algorithm",
        chunks_json=test_chunks
    )
    data = json.loads(result)
    print(f"  Verified: {data.get('verified', False)}")
    
    # Test 2: Hallucination detection
    print("\nTest 2: Hallucination detection")
    halluc_tool = HallucinationDetectionTool()
    
    test_answer = """FCFS is the simplest algorithm [Source 1].
It uses a FIFO queue [Source 1].
It was invented by John Smith in 1970."""  # Hallucination!
    
    result = halluc_tool._run(
        answer=test_answer,
        chunks_json=test_chunks
    )
    data = json.loads(result)
    print(f"  Risk: {data.get('hallucination_risk', 'UNKNOWN')}")
    print(f"  Unsupported claims: {data.get('unsupported_claims', 0)}")
    
    # Test 3: Citation coverage
    print("\nTest 3: Citation coverage")
    coverage_tool = CitationCoverageTool()
    
    result = coverage_tool._run(answer=test_answer)
    data = json.loads(result)
    print(f"  Coverage: {data.get('citation_coverage', '0%')}")
    print(f"  Status: {data.get('status', 'UNKNOWN')}")
    
    print("\n✓ Validation Tool tests passed!")
