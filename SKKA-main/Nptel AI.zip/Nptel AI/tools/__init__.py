"""
Tools Package for NPTEL Agentic RAG System
===========================================

This package contains CrewAI tools that agents use to interact with
the existing ChromaDB retriever and perform specialized operations.

Tools:
- ChromaDBTool: Wraps existing retriever for semantic search
- ContextTool: Manages context window and chunk selection
- CitationTool: Formats citations with clickable links
- ValidationTool: Validates answers against source chunks

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

from .chromadb_tool import (
    ChromaDBTool,
    create_chromadb_tool,
    chromadb_search,
    chromadb_list_courses
)

from .context_tool import (
    ContextTool,
    create_context_tool,
    select_best_chunks,
    estimate_context_tokens
)

from .citation_tool import (
    CitationTool,
    create_citation_tool,
    format_citation,
    enhance_answer_with_links,
    create_source_materials_section
)

from .validation_tool import (
    ValidationTool,
    create_validation_tool,
    verify_claim_in_chunks,
    detect_hallucinations,
    calculate_citation_coverage
)

__all__ = [
    # Tool Classes
    'ChromaDBTool',
    'ContextTool',
    'CitationTool',
    'ValidationTool',
    
    # Creation Functions
    'create_chromadb_tool',
    'create_context_tool',
    'create_citation_tool',
    'create_validation_tool',
    
    # ChromaDB Operations
    'chromadb_search',
    'chromadb_list_courses',
    
    # Context Operations
    'select_best_chunks',
    'estimate_context_tokens',
    
    # Citation Operations
    'format_citation',
    'enhance_answer_with_links',
    'create_source_materials_section',
    
    # Validation Operations
    'verify_claim_in_chunks',
    'detect_hallucinations',
    'calculate_citation_coverage'
]

__version__ = '1.0.0'
