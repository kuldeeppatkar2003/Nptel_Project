"""
Context Tool for NPTEL Agentic RAG System
==========================================

Manages context windows and chunk selection for LLM input.
Ensures retrieved chunks fit within token budgets while maximizing quality.

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
import json
from typing import Dict, List, Any, Optional

from crewai.tools import BaseTool
from pydantic import BaseModel, Field, PrivateAttr

# Import context manager from llm module
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from llm.context_manager import ContextManager, ContextConfig

logger = logging.getLogger(__name__)


# ============================================================================
# TOOL INPUT SCHEMAS
# ============================================================================

class ContextSelectionInput(BaseModel):
    """Input schema for context selection"""
    
    chunks_json: str = Field(
        ...,
        description="JSON string containing retrieved chunks"
    )
    query: str = Field(
        ...,
        description="Original query for relevance scoring"
    )
    max_tokens: int = Field(
        default=6000,
        description="Maximum tokens to fit in context",
        ge=1000,
        le=8000
    )
    strategy: str = Field(
        default="hybrid",
        description="Selection strategy: hybrid, similarity, or diversity"
    )


class TokenEstimationInput(BaseModel):
    """Input schema for token estimation"""
    
    text: str = Field(
        ...,
        description="Text to estimate tokens for"
    )


# ============================================================================
# CONTEXT SELECTION TOOL
# ============================================================================

class ContextTool(BaseTool):
    """
    Context Management Tool.
    
    Selects the best chunks to fit within token budget while
    maximizing information quality and diversity.
    
    Usage by agents:
        selected = context_tool.run(
            chunks_json=retrieval_results,
            query=original_query,
            max_tokens=6000,
            strategy="hybrid"
        )
    """
    
    name: str = "context_selection"
    description: str = """Select best chunks to fit within token budget.
    
Takes retrieved chunks and intelligently selects a subset that:
- Fits within the specified token limit
- Maximizes relevance to the query
- Ensures diversity (avoids redundant information)

Use this before passing chunks to the reasoning agent to ensure
they fit within the LLM's context window."""
    
    args_schema: type[BaseModel] = ContextSelectionInput
    _manager: ContextManager = PrivateAttr()
    
    def __init__(self):
        super().__init__()
        self._manager = ContextManager()
    
    def _run(
        self,
        chunks_json: str,
        query: str,
        max_tokens: int = 6000,
        strategy: str = "hybrid"
    ) -> str:
        """
        Select best chunks within budget.
        
        Args:
            chunks_json: JSON string with chunks
            query: Original query
            max_tokens: Token budget
            strategy: Selection strategy
        
        Returns:
            JSON string with selected chunks
        """
        
        try:
            # Parse chunks
            data = json.loads(chunks_json)
            chunks = data.get('chunks', [])
            
            if not chunks:
                return json.dumps({
                    "selected_chunks": [],
                    "total_selected": 0,
                    "message": "No chunks provided"
                })
            
            # Update strategy
            self._manager.config.selection_strategy = strategy
            
            # Select chunks
            selected = self._manager.select_chunks(
                chunks=chunks,
                query=query,
                max_tokens=max_tokens
            )
            
            # Get stats
            stats = self._manager.get_context_stats(selected)
            
            result = {
                "selected_chunks": selected,
                "total_selected": len(selected),
                "stats": stats,
                "strategy_used": strategy
            }
            
            logger.info(
                f"Selected {len(selected)}/{len(chunks)} chunks "
                f"({stats['token_budget_used']}% of budget)"
            )
            
            return json.dumps(result, indent=2)
            
        except Exception as e:
            logger.error(f"Context selection failed: {e}")
            return json.dumps({
                "error": str(e),
                "selected_chunks": []
            })


# ============================================================================
# TOKEN ESTIMATION TOOL
# ============================================================================

class TokenEstimationTool(BaseTool):
    """Tool for estimating token count"""
    
    name: str = "estimate_tokens"
    description: str = """Estimate token count for text.
    
Returns approximate number of tokens (assuming ~4 chars per token).
Use this to check if text fits within budget before processing."""
    
    args_schema: type[BaseModel] = TokenEstimationInput
    _manager: ContextManager = PrivateAttr()
    
    def __init__(self):
        super().__init__()
        self._manager = ContextManager()
    
    def _run(self, text: str) -> str:
        """
        Estimate tokens.
        
        Args:
            text: Input text
        
        Returns:
            JSON with token estimate
        """
        
        tokens = self._manager.estimate_tokens(text)
        chars = len(text)
        
        result = {
            "text_length_chars": chars,
            "estimated_tokens": tokens,
            "fits_in_6k_budget": tokens <= 6000,
            "fits_in_8k_budget": tokens <= 8000
        }
        
        return json.dumps(result, indent=2)


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_context_tool() -> ContextTool:
    """
    Create context selection tool.
    
    Returns:
        Configured ContextTool
    """
    return ContextTool()


def select_best_chunks(
    chunks: List[Dict[str, Any]],
    query: str,
    max_tokens: int = 6000,
    strategy: str = "hybrid"
) -> List[Dict[str, Any]]:
    """
    Select best chunks (direct function for non-agent use).
    
    Args:
        chunks: List of chunk dicts
        query: Original query
        max_tokens: Token budget
        strategy: Selection strategy
    
    Returns:
        List of selected chunks
    """
    manager = ContextManager()
    manager.config.selection_strategy = strategy
    
    selected = manager.select_chunks(
        chunks=chunks,
        query=query,
        max_tokens=max_tokens
    )
    
    return selected


def estimate_context_tokens(text: str) -> int:
    """
    Estimate tokens in text (direct function).
    
    Args:
        text: Input text
    
    Returns:
        Estimated token count
    """
    manager = ContextManager()
    return manager.estimate_tokens(text)


# ============================================================================
# CHUNK COMPRESSION (ADVANCED)
# ============================================================================

def compress_chunks_to_budget(
    chunks: List[Dict[str, Any]],
    target_tokens: int
) -> List[Dict[str, Any]]:
    """
    Compress chunks by truncating content to fit budget.
    
    This is a fallback when selection alone isn't enough.
    
    Args:
        chunks: Input chunks
        target_tokens: Target token count
    
    Returns:
        Compressed chunks
    """
    manager = ContextManager()
    return manager.compress_chunks(chunks, target_tokens)


# ============================================================================
# DEFAULT TOOL INSTANCE
# ============================================================================

default_context_tool = create_context_tool()
default_token_estimator = TokenEstimationTool()


if __name__ == "__main__":
    # Test the tool
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Context Tool...")
    
    # Create tool
    tool = create_context_tool()
    
    # Test chunks
    test_chunks_json = json.dumps({
        "chunks": [
            {
                "content": "A" * 1000,
                "metadata": {
                    "course_name": "OS",
                    "lecture_no": 1,
                    "similarity_score": 0.9
                }
            },
            {
                "content": "B" * 1000,
                "metadata": {
                    "course_name": "OS",
                    "lecture_no": 2,
                    "similarity_score": 0.8
                }
            },
            {
                "content": "C" * 1000,
                "metadata": {
                    "course_name": "OS",
                    "lecture_no": 3,
                    "similarity_score": 0.7
                }
            }
        ]
    })
    
    # Test selection
    print("\nTest 1: Chunk selection (hybrid strategy)")
    result = tool._run(
        chunks_json=test_chunks_json,
        query="test query",
        max_tokens=1000,
        strategy="hybrid"
    )
    
    data = json.loads(result)
    print(f"  Selected: {data.get('total_selected', 0)} chunks")
    print(f"  Stats: {data.get('stats', {})}")
    
    # Test token estimation
    print("\nTest 2: Token estimation")
    estimator = TokenEstimationTool()
    result = estimator._run(text="This is a test" * 100)
    
    data = json.loads(result)
    print(f"  Chars: {data.get('text_length_chars', 0)}")
    print(f"  Tokens: {data.get('estimated_tokens', 0)}")
    print(f"  Fits in 6K: {data.get('fits_in_6k_budget', False)}")
    
    print("\n✓ Context Tool tests passed!")
