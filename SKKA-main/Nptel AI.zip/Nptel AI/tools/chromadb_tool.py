"""
ChromaDB Tool for NPTEL Agentic RAG System
===========================================

Wraps the existing ChromaDBRetriever as a CrewAI tool so agents
can perform semantic search without modifying existing code.

This tool:
- Interfaces with existing_components/retriever.py
- Provides semantic search capabilities to agents
- Returns structured results with metadata
- Does NOT modify the existing retriever

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import sys
import os
import logging
import json
from typing import Dict, List, Any, Optional
from pathlib import Path

# Add existing_components to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from crewai.tools import BaseTool
from pydantic import BaseModel, Field, PrivateAttr

logger = logging.getLogger(__name__)


# ============================================================================
# IMPORT EXISTING RETRIEVER
# ============================================================================

try:
    from retriever import ChromaDBRetriever, RetrieverConfig
    RETRIEVER_AVAILABLE = True
except ImportError as e:
    logger.error(f"Failed to import existing retriever: {e}")
    RETRIEVER_AVAILABLE = False
    ChromaDBRetriever = None
    RetrieverConfig = None


# ============================================================================
# TOOL INPUT SCHEMAS
# ============================================================================

class ChromaDBSearchInput(BaseModel):
    """Input schema for ChromaDB search"""
    
    query: str = Field(
        ...,
        description="Search query for semantic retrieval from NPTEL lectures"
    )
    k: int = Field(
        default=10,
        description="Number of results to retrieve (default: 10, max: 50)",
        ge=1,
        le=50
    )
    course_name: Optional[str] = Field(
        default=None,
        description="Filter by specific course name (e.g. 'Operating Systems')"
    )
    week_no: Optional[int] = Field(
        default=None,
        description="Filter by week number"
    )
    lecture_no: Optional[int] = Field(
        default=None,
        description="Filter by lecture number"
    )


class ChromaDBListCoursesInput(BaseModel):
    """Input schema for listing courses"""
    
    limit: int = Field(
        default=100,
        description="Maximum courses to return",
        ge=1,
        le=1000
    )


# ============================================================================
# CHROMADB SEARCH TOOL
# ============================================================================

class ChromaDBTool(BaseTool):
    """
    ChromaDB Search Tool for semantic retrieval.
    
    This tool wraps the existing ChromaDBRetriever to provide
    semantic search capabilities to CrewAI agents.
    
    Usage by agents:
        result = chromadb_tool.run(
            query="What is FCFS scheduling?",
            k=10,
            filters={"course_name": "Operating Systems"}
        )
    """
    
    name: str = "chromadb_search"
    description: str = """Search NPTEL lecture transcripts using semantic similarity.
    
Returns the most relevant lecture chunks for a query with:
- Lecture content (text)
- Course name and metadata
- Lecture/week numbers
- PDF and video URLs
- Similarity scores

Use this when you need to find information about specific topics
from NPTEL course materials."""
    
    args_schema: type[BaseModel] = ChromaDBSearchInput
    
    # Class variable to hold shared retriever instance
    _shared_retriever: Optional[Any] = PrivateAttr(default=None)
    
    def __init__(self, retriever: Optional[Any] = None):
        """
        Initialize ChromaDB tool.
        
        Args:
            retriever: Optional pre-initialized retriever
        """
        super().__init__()
        
        if retriever:
            self._shared_retriever = retriever
        elif not self._shared_retriever and RETRIEVER_AVAILABLE:
            # Initialize retriever on first use
            try:
                config = RetrieverConfig()
                self._shared_retriever = ChromaDBRetriever(config)
                logger.info("ChromaDB retriever initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize retriever: {e}")
                raise
    
    def _run(
        self,
        query: str,
        k: int = 10,
        course_name: Optional[str] = None,
        week_no: Optional[int] = None,
        lecture_no: Optional[int] = None
    ) -> str:
        """
        Execute semantic search.
        
        Args:
            query: Search query
            k: Number of results
            filters: Optional metadata filters
        
        Returns:
            JSON string with search results
        """
        
        if not RETRIEVER_AVAILABLE or not self._shared_retriever:
            return json.dumps({
                "error": "ChromaDB retriever not available",
                "chunks": []
            })
        
        try:
            logger.info(f"Searching: query='{query[:50]}...', k={k}, filters={filters}")
            
            # Call existing retriever
            # Construct filters from flattened arguments
            filters = {}
            if course_name:
                filters['course_name'] = course_name
            if week_no:
                filters['week_no'] = week_no
            if lecture_no:
                filters['lecture_no'] = lecture_no
                
            search_filters = filters if filters else None
            
            results = self._shared_retriever.search(
                query=query,
                k=k,
                where=search_filters
            )
            
            # Format for agent consumption
            formatted = self._format_results(results, query)
            
            logger.info(f"Search completed: {len(results)} results")
            return formatted
            
        except Exception as e:
            error_msg = f"Search failed: {str(e)}"
            logger.error(error_msg)
            return json.dumps({
                "error": error_msg,
                "query": query,
                "chunks": []
            })
    
    def _format_results(
        self,
        results: List[Dict[str, Any]],
        query: str
    ) -> str:
        """
        Format results as JSON for agents.
        
        Args:
            results: Raw results from retriever
            query: Original query
        
        Returns:
            JSON string with structured results
        """
        
        if not results:
            return json.dumps({
                "query": query,
                "total_results": 0,
                "message": "No results found",
                "chunks": []
            }, indent=2)
        
        # Calculate quality metrics
        avg_similarity = sum(
            r.get('similarity_score', 0) for r in results
        ) / len(results) if results else 0
        
        unique_lectures = len(set(
            f"{r['metadata'].get('course_name')}_{r['metadata'].get('lecture_no')}"
            for r in results
        ))
        
        # Format chunks
        formatted_chunks = []
        for i, result in enumerate(results, 1):
            chunk = {
                "chunk_id": i,
                "content": result.get('content', ''),
                "metadata": {
                    "course_name": result['metadata'].get('course_name', 'N/A'),
                    "lecture_no": result['metadata'].get('lecture_no', 'N/A'),
                    "week_no": result['metadata'].get('week_no', 'N/A'),
                    "lecture_title": result['metadata'].get('lecture_title', 'N/A'),
                    "similarity_score": round(result.get('similarity_score', 0), 3),
                    "pdf_url": result['metadata'].get('pdf_url', ''),
                    "video_url": result['metadata'].get('video_url', '')
                }
            }
            formatted_chunks.append(chunk)
        
        # Determine confidence level
        if avg_similarity > 0.7:
            confidence = "HIGH"
        elif avg_similarity > 0.5:
            confidence = "MEDIUM"
        else:
            confidence = "LOW"
        
        response = {
            "query": query,
            "total_results": len(results),
            "avg_similarity": round(avg_similarity, 3),
            "retrieval_confidence": confidence,
            "unique_lectures": unique_lectures,
            "chunks": formatted_chunks
        }
        
        return json.dumps(response, indent=2, ensure_ascii=False)


# ============================================================================
# COURSE LIST TOOL
# ============================================================================

class ChromaDBListCoursesTool(BaseTool):
    """Tool for listing available courses in database"""
    
    name: str = "chromadb_list_courses"
    description: str = """List all available NPTEL courses in the database.
    
Use this when you need to:
- Check what courses are available
- Verify if a course is indexed
- Get course metadata"""
    
    args_schema: type[BaseModel] = ChromaDBListCoursesInput
    
    # Shared retriever
    _shared_retriever: Optional[Any] = PrivateAttr(default=None)
    
    def __init__(self, retriever: Optional[Any] = None):
        super().__init__()
        if retriever:
            self._shared_retriever = retriever
        elif not self._shared_retriever and RETRIEVER_AVAILABLE:
            try:
                config = RetrieverConfig()
                self._shared_retriever = ChromaDBRetriever(config)
            except Exception as e:
                logger.error(f"Failed to initialize retriever: {e}")
    
    def _run(self, limit: int = 100) -> str:
        """
        List available courses.
        
        Args:
            limit: Max courses to return
        
        Returns:
            JSON list of courses
        """
        
        if not RETRIEVER_AVAILABLE or not self._shared_retriever:
            return json.dumps({"error": "Retriever not available", "courses": []})
        
        try:
            courses = self._shared_retriever.get_all_courses()[:limit]
            
            return json.dumps({
                "total_courses": len(courses),
                "courses": courses
            }, indent=2)
            
        except Exception as e:
            return json.dumps({
                "error": f"Failed to list courses: {str(e)}",
                "courses": []
            })


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_chromadb_tool(
    retriever: Optional[ChromaDBRetriever] = None # pyright: ignore[reportInvalidTypeForm]
) -> ChromaDBTool:
    """
    Create a ChromaDB tool instance.
    
    Args:
        retriever: Optional existing retriever instance
    
    Returns:
        Configured ChromaDBTool
    
    Example:
        >>> tool = create_chromadb_tool()
        >>> # Or with existing retriever:
        >>> from existing_components.retriever import ChromaDBRetriever, RetrieverConfig
        >>> config = RetrieverConfig()
        >>> retriever = ChromaDBRetriever(config)
        >>> tool = create_chromadb_tool(retriever)
    """
    return ChromaDBTool(retriever=retriever)


def chromadb_search(
    query: str,
    k: int = 10,
    filters: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Direct search function (for non-agent use).
    
    Args:
        query: Search query
        k: Number of results
        filters: Metadata filters
    
    Returns:
        Dict with results
    """
    tool = create_chromadb_tool()
    
    # Decompose filters for new signature
    c_name = filters.get('course_name') if filters else None
    w_no = filters.get('week_no') if filters else None
    l_no = filters.get('lecture_no') if filters else None
    
    result_json = tool._run(
        query=query, 
        k=k, 
        course_name=c_name,
        week_no=w_no,
        lecture_no=l_no
    )
    return json.loads(result_json)


def chromadb_list_courses(limit: int = 100) -> List[str]:
    """
    List available courses (for non-agent use).
    
    Args:
        limit: Max courses
    
    Returns:
        List of course names
    """
    tool = ChromaDBListCoursesTool()
    result_json = tool._run(limit=limit)
    data = json.loads(result_json)
    return data.get('courses', [])


# ============================================================================
# TOOL INSTANCES FOR EXPORT
# ============================================================================

# Create default instances
try:
    default_chromadb_tool = create_chromadb_tool()
    default_courses_tool = ChromaDBListCoursesTool()
except Exception as e:
    logger.warning(f"Could not create default tool instances: {e}")
    default_chromadb_tool = None
    default_courses_tool = None


if __name__ == "__main__":
    # Test the tool
    logging.basicConfig(level=logging.INFO)
    
    print("Testing ChromaDB Tool...")
    
    if not RETRIEVER_AVAILABLE:
        print("❌ Retriever not available - check existing_components/retriever.py")
        sys.exit(1)
    
    # Create tool
    tool = create_chromadb_tool()
    
    # Test search
    print("\nTest 1: Basic search")
    result = tool._run(
        query="FCFS scheduling",
        k=3
    )
    
    data = json.loads(result)
    print(f"  Results: {data.get('total_results', 0)}")
    print(f"  Confidence: {data.get('retrieval_confidence', 'N/A')}")
    
    # Test with filters
    print("\nTest 2: Filtered search")
    result = tool._run(
        query="deadlock",
        k=5,
        filters={"course_name": "Operating Systems"}
    )
    
    data = json.loads(result)
    print(f"  Results: {data.get('total_results', 0)}")
    
    # Test course list
    print("\nTest 3: List courses")
    courses_tool = ChromaDBListCoursesTool()
    result = courses_tool._run(limit=5)
    
    data = json.loads(result)
    print(f"  Courses found: {data.get('total_courses', 0)}")
    
    print("\n✓ ChromaDB Tool tests passed!")
