"""
Workflow Handler for NPTEL Agentic RAG
=======================================

Manages the execution flow, error handling, and result processing
for the 4-agent pipeline.

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
import time
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


# ============================================================================
# WORKFLOW CONFIGURATION
# ============================================================================

@dataclass
class WorkflowConfig:
    """Configuration for workflow execution"""
    
    # Execution settings
    max_retries: int = 3
    retry_delay: float = 2.0
    timeout_seconds: int = 300
    
    # Output settings
    save_intermediate: bool = True
    output_dir: str = "data/workflow_outputs"
    
    # Logging
    log_execution: bool = True
    log_level: str = "INFO"


# ============================================================================
# EXECUTION METRICS
# ============================================================================

@dataclass
class ExecutionMetrics:
    """Track execution metrics for the workflow"""
    
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    
    total_queries: int = 0
    successful_queries: int = 0
    failed_queries: int = 0
    
    stage_durations: Dict[str, List[float]] = field(default_factory=dict)
    
    def record_stage(self, stage: str, duration: float):
        """Record duration for a stage"""
        if stage not in self.stage_durations:
            self.stage_durations[stage] = []
        self.stage_durations[stage].append(duration)
    
    def finalize(self):
        """Mark execution as complete"""
        self.end_time = datetime.now()
    
    def get_summary(self) -> Dict[str, Any]:
        """Get execution summary"""
        duration = (self.end_time or datetime.now()) - self.start_time
        
        summary = {
            'total_queries': self.total_queries,
            'successful': self.successful_queries,
            'failed': self.failed_queries,
            'success_rate': (
                self.successful_queries / self.total_queries * 100
                if self.total_queries > 0 else 0
            ),
            'total_duration_seconds': duration.total_seconds(),
            'stage_stats': {}
        }
        
        # Calculate stage statistics
        for stage, durations in self.stage_durations.items():
            if durations:
                summary['stage_stats'][stage] = {
                    'avg_duration': sum(durations) / len(durations),
                    'min_duration': min(durations),
                    'max_duration': max(durations),
                    'total_calls': len(durations)
                }
        
        return summary


# ============================================================================
# WORKFLOW HANDLER
# ============================================================================

class WorkflowHandler:
    """
    Manages the execution of the NPTEL Agentic RAG workflow.
    
    Responsibilities:
    - Execute the 4-agent pipeline
    - Handle errors and retries
    - Track execution metrics
    - Save intermediate results
    - Format final output
    
    Example:
        >>> from crew.nptel_crew import NPTELCrew
        >>> crew = NPTELCrew(llm=llm)
        >>> workflow = WorkflowHandler(crew)
        >>> result = workflow.execute("What is machine learning?")
    """
    
    def __init__(
        self,
        crew,
        config: Optional[WorkflowConfig] = None
    ):
        """
        Initialize workflow handler.
        
        Args:
            crew: NPTELCrew instance
            config: Workflow configuration
        """
        self.crew = crew
        self.config = config or WorkflowConfig()
        self.metrics = ExecutionMetrics()
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(getattr(logging, self.config.log_level))
        
        self.logger.info("✅ Workflow Handler initialized")
    
    def execute(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None,
        retry: bool = True
    ) -> Dict[str, Any]:
        """
        Execute the full workflow for a query.
        
        Args:
            query: User's question
            context: Optional context
            retry: Enable automatic retry on failure
        
        Returns:
            Workflow result with answer and metadata
        
        Raises:
            WorkflowExecutionError: If execution fails after retries
        """
        self.metrics.total_queries += 1
        
        self.logger.info("=" * 80)
        self.logger.info(f"WORKFLOW EXECUTION START")
        self.logger.info(f"Query: {query}")
        self.logger.info("=" * 80)
        
        start_time = time.time()
        
        # Execute with retry logic
        for attempt in range(1, self.config.max_retries + 1):
            try:
                self.logger.info(f"Attempt {attempt}/{self.config.max_retries}")
                
                # Execute the crew
                result = self._execute_pipeline(query, context)
                
                # Record success
                self.metrics.successful_queries += 1
                duration = time.time() - start_time
                
                self.logger.info(f"✅ Workflow completed successfully in {duration:.2f}s")
                
                # Structure and return result
                final_result = self._structure_result(result, query, duration)
                
                # Save if configured
                if self.config.save_intermediate:
                    self._save_result(final_result)
                
                return final_result
                
            except Exception as e:
                self.logger.error(f"❌ Attempt {attempt} failed: {e}")
                
                if attempt < self.config.max_retries and retry:
                    self.logger.info(f"Retrying in {self.config.retry_delay}s...")
                    time.sleep(self.config.retry_delay)
                else:
                    # Final failure
                    self.metrics.failed_queries += 1
                    duration = time.time() - start_time
                    
                    self.logger.error(f"❌ Workflow failed after {attempt} attempts")
                    
                    # Return error result
                    return self._create_error_result(query, str(e), duration)
    
    def _execute_pipeline(
        self,
        query: str,
        context: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Execute the actual 4-agent pipeline with timing.
        
        Args:
            query: User query
            context: Optional context
        
        Returns:
            Raw result from crew
        """
        # Execute crew
        stage_start = time.time()
        result = self.crew.execute(query, context)
        stage_duration = time.time() - stage_start
        
        # Record metrics
        self.metrics.record_stage("full_pipeline", stage_duration)
        
        return result
    
    def _structure_result(
        self,
        raw_result: Dict[str, Any],
        query: str,
        duration: float
    ) -> Dict[str, Any]:
        """
        Structure the raw crew output into final format.
        
        Args:
            raw_result: Raw output from crew
            query: Original query
            duration: Execution duration
        
        Returns:
            Structured result dictionary
        """
        # Extract components
        final_answer = raw_result.get('final_answer', '')
        validation_report = raw_result.get('validation_report', {})
        
        # Build structured result
        result = {
            # Query info
            'query': query,
            'timestamp': datetime.now().isoformat(),
            
            # Answer
            'final_answer': final_answer,
            'status': raw_result.get('status', 'COMPLETED'),
            
            # Pipeline outputs
            'planning_output': raw_result.get('planning_output'),
            'retrieval_output': raw_result.get('retrieval_output'),
            'reasoning_output': raw_result.get('reasoning_output'),
            
            # Validation
            'validation_report': validation_report,
            'validation_status': validation_report.get('validation_status', 'UNKNOWN'),
            'quality_score': validation_report.get('quality_score', 0),
            'citation_coverage': validation_report.get('citation_coverage', 0),
            'hallucination_risk': validation_report.get('hallucination_risk', 'UNKNOWN'),
            
            # Metadata
            'execution_time_seconds': duration,
            'pipeline_version': '1.0.0',
            'workflow_metrics': self._get_current_metrics()
        }
        
        return result
    
    def _create_error_result(
        self,
        query: str,
        error_message: str,
        duration: float
    ) -> Dict[str, Any]:
        """
        Create an error result when execution fails.
        
        Args:
            query: Original query
            error_message: Error description
            duration: Execution duration
        
        Returns:
            Error result dictionary
        """
        return {
            'query': query,
            'timestamp': datetime.now().isoformat(),
            'status': 'FAILED',
            'error': error_message,
            'final_answer': f"Sorry, I encountered an error processing your query: {error_message}",
            'validation_report': {},
            'validation_status': 'FAILED',
            'execution_time_seconds': duration,
            'workflow_metrics': self._get_current_metrics()
        }
    
    def _get_current_metrics(self) -> Dict[str, Any]:
        """Get current workflow metrics"""
        return {
            'total_queries': self.metrics.total_queries,
            'successful_queries': self.metrics.successful_queries,
            'failed_queries': self.metrics.failed_queries
        }
    
    def _save_result(self, result: Dict[str, Any]):
        """
        Save result to file.
        
        Args:
            result: Result to save
        """
        import os
        from pathlib import Path
        
        # Create output directory
        output_dir = Path(self.config.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        query_slug = result['query'][:30].replace(' ', '_')
        filename = f"{timestamp}_{query_slug}.json"
        
        filepath = output_dir / filename
        
        # Save
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
            
            self.logger.debug(f"Saved result to: {filepath}")
        except Exception as e:
            self.logger.warning(f"Failed to save result: {e}")
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """
        Get comprehensive metrics summary.
        
        Returns:
            Metrics summary dictionary
        """
        self.metrics.finalize()
        return self.metrics.get_summary()
    
    def reset_metrics(self):
        """Reset all metrics"""
        self.metrics = ExecutionMetrics()
        self.logger.info("Metrics reset")


# ============================================================================
# BATCH EXECUTION
# ============================================================================

class BatchWorkflowHandler(WorkflowHandler):
    """
    Extended workflow handler for batch query processing.
    
    Example:
        >>> queries = ["Query 1", "Query 2", "Query 3"]
        >>> batch = BatchWorkflowHandler(crew)
        >>> results = batch.execute_batch(queries)
    """
    
    def execute_batch(
        self,
        queries: List[str],
        context: Optional[Dict[str, Any]] = None,
        show_progress: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Execute workflow for multiple queries.
        
        Args:
            queries: List of queries to process
            context: Optional context for all queries
            show_progress: Show progress bar
        
        Returns:
            List of results
        """
        self.logger.info(f"Starting batch execution for {len(queries)} queries")
        
        results = []
        
        # Optional progress bar
        if show_progress:
            try:
                from tqdm import tqdm
                iterator = tqdm(queries, desc="Processing queries")
            except ImportError:
                iterator = queries
        else:
            iterator = queries
        
        # Process each query
        for query in iterator:
            result = self.execute(query, context, retry=True)
            results.append(result)
        
        self.logger.info(f"✅ Batch execution complete: {len(results)} results")
        
        return results
    
    def execute_batch_parallel(
        self,
        queries: List[str],
        context: Optional[Dict[str, Any]] = None,
        max_workers: int = 4
    ) -> List[Dict[str, Any]]:
        """
        Execute workflow for multiple queries in parallel.
        
        Args:
            queries: List of queries
            context: Optional context
            max_workers: Maximum parallel workers
        
        Returns:
            List of results
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed
        
        self.logger.info(
            f"Starting parallel batch execution: "
            f"{len(queries)} queries, {max_workers} workers"
        )
        
        results = []
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all queries
            future_to_query = {
                executor.submit(self.execute, query, context): query
                for query in queries
            }
            
            # Collect results as they complete
            for future in as_completed(future_to_query):
                query = future_to_query[future]
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    self.logger.error(f"Query failed: {query} - {e}")
                    results.append(self._create_error_result(query, str(e), 0))
        
        self.logger.info(f"✅ Parallel batch execution complete")
        
        return results


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_workflow_handler(
    crew,
    **config_kwargs
) -> WorkflowHandler:
    """
    Create a workflow handler with custom configuration.
    
    Args:
        crew: NPTELCrew instance
        **config_kwargs: Configuration parameters
    
    Returns:
        Configured WorkflowHandler
    
    Example:
        >>> handler = create_workflow_handler(
        ...     crew,
        ...     max_retries=5,
        ...     save_intermediate=True
        ... )
    """
    config = WorkflowConfig(**config_kwargs)
    return WorkflowHandler(crew, config)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s | %(levelname)-8s | %(message)s'
    )
    
    print("\n" + "=" * 80)
    print("TESTING WORKFLOW HANDLER")
    print("=" * 80 + "\n")
    
    # Mock crew for testing
    class MockCrew:
        def execute(self, query, context):
            time.sleep(1)  # Simulate processing
            return {
                'final_answer': f"Mock answer for: {query}",
                'status': 'APPROVED',
                'validation_report': {
                    'validation_status': 'APPROVED',
                    'quality_score': 0.95,
                    'citation_coverage': 100,
                    'hallucination_risk': 'LOW'
                }
            }
    
    # Create workflow
    mock_crew = MockCrew()
    workflow = WorkflowHandler(mock_crew)
    
    # Test single execution
    print("Test 1: Single Query Execution")
    result = workflow.execute("What is machine learning?")
    
    print(f"\nStatus: {result['status']}")
    print(f"Answer: {result['final_answer']}")
    print(f"Duration: {result['execution_time_seconds']:.2f}s")
    
    # Test batch execution
    print("\n" + "-" * 80)
    print("Test 2: Batch Execution")
    
    batch_handler = BatchWorkflowHandler(mock_crew)
    queries = [
        "What is AI?",
        "What is ML?",
        "What is DL?"
    ]
    
    results = batch_handler.execute_batch(queries, show_progress=False)
    
    print(f"\nProcessed {len(results)} queries")
    
    # Show metrics
    metrics = batch_handler.get_metrics_summary()
    print("\n📊 Metrics:")
    print(f"  Total Queries: {metrics['total_queries']}")
    print(f"  Success Rate: {metrics['success_rate']:.1f}%")
    print(f"  Total Duration: {metrics['total_duration_seconds']:.2f}s")
    
    print("\n" + "=" * 80)
    print("TEST COMPLETE")
    print("=" * 80 + "\n")