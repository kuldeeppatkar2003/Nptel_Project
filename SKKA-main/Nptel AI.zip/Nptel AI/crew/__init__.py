"""
NPTEL Academic Assistant - Crew Package
========================================

Multi-agent system for intelligent NPTEL content retrieval and synthesis.

Author: DBDA Student
Version: 1.0.0
Python: 3.8+

This package provides:
- NPTELCrew: Main crew orchestrator with specialized agents
- WorkflowHandler: Execution flow and task management
"""

from .nptel_crew import NPTELCrew
from .workflow_handler import WorkflowHandler

__version__ = "1.0.0"
__author__ = "DBDA Student"

__all__ = [
    "NPTELCrew",
    "WorkflowHandler",
]
