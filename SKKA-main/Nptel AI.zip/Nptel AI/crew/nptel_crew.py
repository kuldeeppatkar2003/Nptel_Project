"""
NPTEL Crew - Main Orchestration
================================

This is the central orchestrator that brings together all 4 agents
to create the complete Agentic RAG pipeline.

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
import os
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from pathlib import Path

from crewai import Crew, Process, LLM
from langchain_ollama import ChatOllama

# Set environment for UTF-8 and dummy OpenAI key
import sys
import io

# Force UTF-8 for all stdout/stderr to prevent charmap errors on Windows
if hasattr(sys.stdout, 'buffer'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
if hasattr(sys.stderr, 'buffer'):
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

os.environ["PYTHONIOENCODING"] = "utf-8"
os.environ["PYTHONIOENCODING"] = "utf-8"
# Note: OPENAI_API_KEY is now loaded from .env via python-dotenv if available
from dotenv import load_dotenv
load_dotenv()

# Ensure dummy key exists if not set (required by CrewAI)
if "OPENAI_API_KEY" not in os.environ:
    os.environ["OPENAI_API_KEY"] = "NA"

# Import agents
from agents.planner_agent import create_planner_agent
from agents.retriever_agent import create_retriever_agent
from agents.reasoning_agent import create_reasoning_agent
from agents.validator_agent import create_validator_agent

# Import tasks
from task.planning_task import create_planning_task
from task.retrieval_task import create_retrieval_task
from task.reasoning_task import create_reasoning_task
from task.validation_task import create_validation_task

# Import tools
from tools.chromadb_tool import create_chromadb_tool

logger = logging.getLogger(__name__)


# ============================================================================
# CONFIGURATION
# ============================================================================

@dataclass
class NPTELCrewConfig:
    """Configuration for NPTEL Crew"""
    
    # LLM settings
    llm_model: str = os.getenv("LLM_MODEL", "ollama/mistral")
    llm_base_url: str = os.getenv("LLM_BASE_URL", "http://localhost:11434")
    llm_temperature: float = float(os.getenv("LLM_TEMPERATURE", "0.1"))
    
    # Process settings
    process_type: str = "sequential"  # sequential or hierarchical
    verbose: bool = True
    
    # Agent settings
    enable_memory: bool = True
    max_iterations: int = 5
    
    # Retrieval settings
    default_k: int = 10
    min_similarity: float = 0.3
    
    # Validation settings
    # Validation settings
    strict_mode: bool = os.getenv("STRICT_MODE", "False").lower() == "true"


# ============================================================================
# MAIN CREW CLASS
# ============================================================================

class NPTELCrew:
    """
    Main orchestrator for the NPTEL Agentic RAG system.
    
    This class manages the 4-agent pipeline:
    1. Planner Agent - Analyzes query and creates retrieval strategy
    2. Retriever Agent - Executes semantic search
    3. Reasoning Agent - Synthesizes grounded answer
    4. Validator Agent - Validates answer quality
    
    Example:
        >>> from langchain_community.llms import Ollama
        >>> llm = Ollama(model="mistral")
        >>> crew = NPTELCrew(llm=llm)
        >>> result = crew.execute("What is thrust in rockets?")
    """
    
    def __init__(
        self,
        llm: Optional[Any] = None,
        config: Optional[NPTELCrewConfig] = None,
        verbose: bool = True
    ):
        """
        Initialize the NPTEL Crew.
        
        Args:
            llm: Language model instance (Ollama/Mistral)
            config: Crew configuration
            verbose: Enable verbose logging
        """
        self.config = config or NPTELCrewConfig()
        self.verbose = verbose
        
        # Initialize LLM
        if llm is None:
            logger.info(f"Initializing default LLM: {self.config.llm_model}")
            # Determine correct base_url
            model_name = self.config.llm_model
            base_url = self.config.llm_base_url
            
            # If using Groq and base_url is localhost (default), clear it
            if "groq" in model_name.lower() and "localhost" in str(base_url):
                base_url = None
                
            self.llm = LLM(
                model=model_name,
                base_url=base_url,
                temperature=self.config.llm_temperature,
                timeout=1200
            )
        else:
            self.llm = llm
        
        # Initialize tools
        self._init_tools()
        
        # Initialize agents
        self._init_agents()
        
        # Crew will be created per query
        self.crew = None
        
        logger.info("NPTEL Crew initialized successfully")
    
    def _init_tools(self):
        """Initialize all tools for the crew"""
        logger.info("Initializing tools...")
        
        # ChromaDB search tool (primary tool)
        self.chromadb_tool = create_chromadb_tool()
        
        logger.info("Tools initialized")
    
    def _init_agents(self):
        """Initialize all 4 agents"""
        logger.info("Initializing agents...")
        
        # Agent 1: Planner
        self.planner = create_planner_agent(
            llm=self.llm,
            verbose=self.verbose
        )
        logger.info("  [PLANNER] Planner Agent ready")
        
        # Agent 2: Retriever (needs tools)
        self.retriever = create_retriever_agent(
            llm=self.llm,
            tools=[self.chromadb_tool],
            verbose=self.verbose
        )
        logger.info("  [RETRIEVER] Retriever Agent ready")
        
        # Agent 3: Reasoning
        self.reasoning = create_reasoning_agent(
            llm=self.llm,
            strict_mode=self.config.strict_mode,
            verbose=self.verbose
        )
        logger.info("  [REASONING] Reasoning Agent ready")
        
        # Agent 4: Validator
        self.validator = create_validator_agent(
            llm=self.llm,
            strict_mode=self.config.strict_mode,
            verbose=self.verbose
        )
        logger.info("  [VALIDATOR] Validator Agent ready")
        
        logger.info("All agents initialized")
    
    def execute(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Execute the full 4-agent pipeline for a query.
        
        Args:
            query: User's question
            context: Optional context (course filters, etc.)
        
        Returns:
            Dictionary with results from all agents
        
        Example:
            >>> result = crew.execute("What is FCFS scheduling?")
            >>> print(result['final_answer'])
        """
        logger.info("=" * 80)
        logger.info(f"EXECUTING PIPELINE FOR QUERY: {query}")
        logger.info("=" * 80)
        
        # Step 1: Create tasks for this query
        tasks = self._create_tasks(query, context)
        
        # Step 2: Create crew with these tasks
        self.crew = Crew(
            agents=[self.planner, self.retriever, self.reasoning, self.validator],
            tasks=tasks,
            process=Process.sequential,  # Execute in order
            verbose=self.verbose
        )
        
        # Step 3: Execute the crew
        logger.info("Starting crew execution...")
        
        try:
            result = self.crew.kickoff()
            
            logger.info("Pipeline execution complete")
            
            # Parse and structure the result
            structured_result = self._structure_result(result, tasks)
            
            return structured_result
            
        except Exception as e:
            logger.error(f"❌ Pipeline execution failed: {e}", exc_info=True)
            raise
    
    def _create_tasks(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> List:
        """
        Create the 4 tasks for the pipeline.
        
        Args:
            query: User query
            context: Optional context
        
        Returns:
            List of CrewAI Task objects
        """
        logger.info("Creating tasks for pipeline...")
        
        # Task 1: Planning
        planning_task = create_planning_task(
            query=query,
            context=context or {},
            agent=self.planner,
            verbose=self.verbose
        )
        
        # Task 2: Retrieval
        # Note: This task will use planner's output
        retrieval_task = create_retrieval_task(
            query=query,
            planning_output="",  # Will be filled by CrewAI from context
            agent=self.retriever,
            verbose=self.verbose
        )
        # Set context dependency
        retrieval_task.context = [planning_task]
        
        # Task 3: Reasoning
        reasoning_task = create_reasoning_task(
            query=query,
            retrieval_output="",  # Will be filled from context
            planning_output="",   # Will be filled from context
            agent=self.reasoning,
            verbose=self.verbose
        )
        reasoning_task.context = [planning_task, retrieval_task]
        
        # Task 4: Validation
        validation_task = create_validation_task(
            reasoning_output="",  # Will be filled from context
            retrieval_output="",  # Will be filled from context
            agent=self.validator,
            strict_mode=self.config.strict_mode,
            verbose=self.verbose
        )
        validation_task.context = [reasoning_task, retrieval_task]
        
        logger.info("All tasks created")
        
        return [planning_task, retrieval_task, reasoning_task, validation_task]
    
    def _structure_result(
        self,
        raw_result: Any,
        tasks: List
    ) -> Dict[str, Any]:
        """
        Structure the raw CrewAI output into a clean result.
        
        Args:
            raw_result: Raw output from CrewAI
            tasks: List of tasks that were executed
        
        Returns:
            Structured result dictionary
        """
        # The final result is the validator's output
        final_output = str(raw_result)
        
        # Try to parse as JSON if possible
        import json
        try:
            final_result = json.loads(final_output)
        except:
            # If not JSON, structure manually
            final_result = {
                "status": "COMPLETED",
                "final_answer": final_output,
                "validation_status": "APPROVED"  # Assume approved if no issues
            }
        
        # Add task outputs
        result = {
            "query": tasks[0].description.split("QUERY:")[1].split("\n")[0].strip() if "QUERY:" in tasks[0].description else "Unknown",
            "planning_output": getattr(tasks[0], 'output', None),
            "retrieval_output": getattr(tasks[1], 'output', None),
            "reasoning_output": getattr(tasks[2], 'output', None),
            "validation_output": final_result,
            "final_answer": final_result.get('enhanced_answer', final_result.get('final_answer', final_output)),
            "validation_report": final_result if isinstance(final_result, dict) else {},
            "status": final_result.get('validation_status', 'COMPLETED') if isinstance(final_result, dict) else 'COMPLETED'
        }
        
        return result
    
    def get_agent_info(self) -> Dict[str, Any]:
        """
        Get information about all agents in the crew.
        
        Returns:
            Dictionary with agent details
        """
        return {
            "planner": {
                "role": self.planner.role,
                "goal": self.planner.goal
            },
            "retriever": {
                "role": self.retriever.role,
                "goal": self.retriever.goal,
                "tools": len(self.retriever.tools)
            },
            "reasoning": {
                "role": self.reasoning.role,
                "goal": self.reasoning.goal
            },
            "validator": {
                "role": self.validator.role,
                "goal": self.validator.goal
            }
        }
    
    def reset(self):
        """Reset the crew (clear any cached state)"""
        logger.info("Resetting crew...")
        self.crew = None
        logger.info("Crew reset complete")


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_nptel_crew(
    llm: Optional[Any] = None,
    verbose: bool = True,
    **kwargs
) -> NPTELCrew:
    """
    Convenience function to create NPTEL Crew.
    
    Args:
        llm: Language model
        verbose: Enable verbose mode
        **kwargs: Additional config parameters
    
    Returns:
        Configured NPTELCrew
    
    Example:
        >>> crew = create_nptel_crew(verbose=True)
        >>> result = crew.execute("What is machine learning?")
    """
    config = NPTELCrewConfig(**kwargs) if kwargs else NPTELCrewConfig()
    return NPTELCrew(llm=llm, config=config, verbose=verbose)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s | %(levelname)-8s | %(message)s'
    )
    
    print("\n" + "=" * 80)
    print("TESTING NPTEL CREW")
    print("=" * 80 + "\n")
    
    # Create LLM
    print("Initializing TinyLlama LLM...")
    llm = LLM(model="ollama/mistral", temperature=0.1, timeout=1200)
    
    # Create crew
    print("\nCreating NPTEL Crew...")
    crew = create_nptel_crew(llm=llm, verbose=True)
    
    # Show agent info
    print("\n📋 Agent Information:")
    agent_info = crew.get_agent_info()
    for agent_name, info in agent_info.items():
        print(f"\n  {agent_name.upper()}:")
        print(f"    Role: {info['role']}")
        print(f"    Goal: {info['goal'][:80]}...")
    
    # Test query
    print("\n" + "=" * 80)
    print("RUNNING TEST QUERY")
    print("=" * 80 + "\n")
    
    test_query = "What is thrust in rockets?"
    
    try:
        result = crew.execute(test_query)
        
        print("\nEXECUTION SUCCESSFUL\n")
        print("📖 Final Answer:")
        print(result['final_answer'])
        
        print("\n📊 Validation Status:")
        print(f"  Status: {result['status']}")
        
    except Exception as e:
        print(f"\n❌ Execution failed: {e}")
    
    print("\n" + "=" * 80)
    print("TEST COMPLETE")
    print("=" * 80 + "\n")