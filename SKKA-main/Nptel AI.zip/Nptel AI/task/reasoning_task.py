"""
Reasoning Task for NPTEL Agentic RAG System
============================================

The Reasoning Task is executed by the Reasoning Agent.
It synthesizes grounded answers from retrieved chunks.

Output: Well-cited answer with source attribution

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
from typing import Dict, Any, Optional
from crewai import Task

logger = logging.getLogger(__name__)


class ReasoningTask:
    """
    Reasoning Task - Answer Synthesis
    
    This task is assigned to the Reasoning Agent.
    
    Inputs:
    - Original query
    - Retrieved chunks (from retrieval task)
    - Planning output (for context)
    
    Outputs:
    - Grounded answer with inline citations
    - Sources used
    - Confidence score
    - Completeness assessment
    
    Example:
        >>> from agents.reasoning_agent import create_reasoning_agent
        >>> reasoning = create_reasoning_agent(llm)
        >>> task = ReasoningTask.create_task(
        ...     query="What is FCFS?",
        ...     retrieval_output=chunks_json,
        ...     planning_output=plan_json,
        ...     agent=reasoning
        ... )
    """
    
    @staticmethod
    def create_task(
        query: str,
        retrieval_output: str,
        planning_output: str,
        agent = None,
        verbose: bool = True
    ) -> Task:
        """
        Create a reasoning task.
        
        Args:
            query: Original student question
            retrieval_output: Output from retrieval task (JSON)
            planning_output: Output from planning task (JSON)
            agent: Reasoning agent instance
            verbose: Enable verbose output
        
        Returns:
            Configured Task object
        """
        
        from llm.prompts import format_reasoning_prompt
        
        # Format the task description
        description = format_reasoning_prompt(
            query,
            retrieval_output,
            planning_output
        )
        
        # Expected output structure
        expected_output = """Provide your answer in markdown format with inline citations [Source X].

Then provide metadata as JSON:
{
    "answer_type": "definition|explanation|comparison|step-by-step",
    "sources_used": [
        {"source_id": 1, "lecture": X, "citations": N},
        {"source_id": 2, "lecture": Y, "citations": N}
    ],
    "confidence": 0.XX,
    "completeness": "full|partial|insufficient",
    "limitations": "Any gaps or limitations noted"
}"""
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            
            # Task configuration
            async_execution=False,
            
            # Context from previous tasks
            context=[],  # Populated by CrewAI
        )
        
        if verbose:
            logger.info(f"Created Reasoning Task for query: {query[:50]}...")
        
        return task
    
    @staticmethod
    def create_simple_reasoning_task(
        query: str,
        chunks: str,
        agent = None
    ) -> Task:
        """
        Create a simplified reasoning task.
        
        Args:
            query: Student's question
            chunks: Retrieved chunks (JSON or text)
            agent: Reasoning agent
        
        Returns:
            Task object
        """
        
        description = f"""Generate a grounded answer using these lecture chunks:

**QUERY:** {query}

**LECTURE CHUNKS:**
{chunks}

**INSTRUCTIONS:**
1. Answer using ONLY information from chunks above
2. Add citation [Source X] for every claim
3. If information is incomplete, state this clearly
4. Explain pedagogically (as if teaching a student)

Provide answer in markdown with citations."""
        
        expected_output = "Markdown answer with inline citations [Source X]"
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            async_execution=False
        )
        
        return task
    
    @staticmethod
    def create_comparative_reasoning_task(
        query: str,
        retrieval_output: str,
        concepts: list,
        agent = None
    ) -> Task:
        """
        Create reasoning task optimized for comparisons.
        
        Args:
            query: Comparison question
            retrieval_output: Retrieved chunks
            concepts: List of concepts to compare
            agent: Reasoning agent
        
        Returns:
            Task object
        """
        
        description = f"""Generate a comparative answer:

**QUERY:** {query}

**CONCEPTS TO COMPARE:** {', '.join(concepts)}

**RETRIEVED CHUNKS:**
{retrieval_output}

**INSTRUCTIONS:**
1. Explain each concept separately [with citations]
2. Then compare them systematically
3. Highlight key differences
4. Use table or structured format if helpful
5. Every claim must have [Source X]

Structure: Define â†' Compare â†' Key Differences"""
        
        expected_output = "Comparative analysis with citations"
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            async_execution=False
        )
        
        return task


def create_reasoning_task(
    query: str,
    retrieval_output: str,
    planning_output: str,
    agent = None,
    verbose: bool = True
) -> Task:
    """
    Convenience function to create reasoning task.
    
    Args:
        query: Student's question
        retrieval_output: Retrieval task output (JSON)
        planning_output: Planning task output (JSON)
        agent: Reasoning agent instance
        verbose: Enable verbose logging
    
    Returns:
        Configured Task
    
    Example:
        >>> task = create_reasoning_task(
        ...     query="Explain FCFS",
        ...     retrieval_output=chunks_json,
        ...     planning_output=plan_json,
        ...     agent=reasoning_agent
        ... )
    """
    return ReasoningTask.create_task(
        query=query,
        retrieval_output=retrieval_output,
        planning_output=planning_output,
        agent=agent,
        verbose=verbose
    )


# ============================================================================
# TASK CONFIGURATION HELPERS
# ============================================================================

def get_reasoning_task_config() -> Dict[str, Any]:
    """
    Get configuration for reasoning task.
    
    Returns:
        Dict with task configuration
    """
    return {
        "task_name": "Answer Synthesis",
        "agent_required": "ReasoningAgent",
        "execution_mode": "synchronous",
        "inputs": ["query", "retrieval_output", "planning_output"],
        "outputs": [
            "markdown_answer",
            "citations",
            "confidence_score",
            "completeness"
        ],
        "expected_duration_seconds": 10,
        "dependencies": ["planning_task", "retrieval_task"],
        "critical_requirements": [
            "No hallucination",
            "100% citation coverage",
            "Grounded in sources"
        ]
    }


def validate_reasoning_output(output: str) -> Dict[str, Any]:
    """
    Validate reasoning task output.
    
    Args:
        output: Task output string
    
    Returns:
        Dict with validation results
    """
    validation = {
        'has_answer': False,
        'has_citations': False,
        'has_metadata': False,
        'citation_count': 0,
        'valid': False
    }
    
    # Check for answer content
    if len(output) > 50:
        validation['has_answer'] = True
    
    # Check for citations
    import re
    citations = re.findall(r'\[Source \d+\]', output)
    validation['citation_count'] = len(citations)
    validation['has_citations'] = len(citations) > 0
    
    # Check for JSON metadata (optional)
    if '{' in output and '}' in output:
        validation['has_metadata'] = True
    
    # Overall validation
    validation['valid'] = (
        validation['has_answer'] and
        validation['has_citations']
    )
    
    if not validation['valid']:
        logger.warning(f"Reasoning output validation failed: {validation}")
    
    return validation


def extract_answer_and_metadata(output: str) -> Dict[str, Any]:
    """
    Extract answer and metadata from reasoning output.
    
    Args:
        output: Reasoning task output
    
    Returns:
        Dict with answer and metadata
    """
    import json
    import re
    
    result = {
        'answer': '',
        'metadata': {},
        'citations': []
    }
    
    # Try to split answer and JSON metadata
    json_match = re.search(r'```json\n(.*?)\n```', output, re.DOTALL)
    
    if json_match:
        # Extract JSON metadata
        try:
            result['metadata'] = json.loads(json_match.group(1))
        except:
            pass
        
        # Answer is everything before JSON
        result['answer'] = output[:json_match.start()].strip()
    else:
        # No JSON found, entire output is answer
        result['answer'] = output.strip()
    
    # Extract citations
    result['citations'] = re.findall(r'\[Source (\d+)\]', output)
    
    return result


def count_citations(output: str) -> int:
    """
    Count number of citations in answer.
    
    Args:
        output: Reasoning task output
    
    Returns:
        Number of [Source X] citations
    """
    import re
    citations = re.findall(r'\[Source \d+\]', output)
    return len(citations)


def get_unique_sources(output: str) -> list:
    """
    Get list of unique source IDs used.
    
    Args:
        output: Reasoning task output
    
    Returns:
        List of unique source IDs
    """
    import re
    citations = re.findall(r'\[Source (\d+)\]', output)
    return sorted(set(int(c) for c in citations))


if __name__ == "__main__":
    # Test task creation
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Reasoning Task creation...")
    
    # Create a mock agent
    from agents.reasoning_agent import create_reasoning_agent
    from langchain_community.llms import Ollama
    
    llm = Ollama(model="mistral", temperature=0.1)
    reasoning = create_reasoning_agent(llm, strict_mode=True)
    
    # Mock inputs
    test_query = "What is FCFS scheduling?"
    
    mock_retrieval = """{
        "chunks": [
            {
                "content": "FCFS is the simplest scheduling algorithm.",
                "metadata": {"course_name": "OS", "lecture_no": 15}
            }
        ]
    }"""
    
    mock_planning = """{
        "query_type": "definition",
        "expected_answer_type": "definition"
    }"""
    
    # Create task
    task = create_reasoning_task(
        query=test_query,
        retrieval_output=mock_retrieval,
        planning_output=mock_planning,
        agent=reasoning,
        verbose=True
    )
    
    print(f"\n✅ Reasoning Task created!")
    print(f"Description length: {len(task.description)} chars")
    
    # Show configuration
    print(f"\nTask configuration:")
    config = get_reasoning_task_config()
    for key, value in config.items():
        print(f"  {key}: {value}")
    
    # Test validation (with mock output)
    mock_output = """FCFS (First-Come-First-Served) is the simplest CPU scheduling algorithm [Source 1]. 
Processes are executed in the order they arrive [Source 1].

```json
{
    "answer_type": "definition",
    "confidence": 0.95,
    "completeness": "full"
}
```"""
    
    validation = validate_reasoning_output(mock_output)
    print(f"\nMock output validation:")
    for key, value in validation.items():
        print(f"  {key}: {value}")
    
    # Test extraction
    extracted = extract_answer_and_metadata(mock_output)
    print(f"\nExtracted answer length: {len(extracted['answer'])} chars")
    print(f"Citations found: {len(extracted['citations'])}")
    print(f"Unique sources: {get_unique_sources(mock_output)}")
