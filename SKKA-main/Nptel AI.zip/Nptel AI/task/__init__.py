"""
Tasks Package for NPTEL Agentic RAG System
===========================================

This package contains all CrewAI tasks for the RAG pipeline.

Tasks:
- PlanningTask: Query analysis and strategy creation
- RetrievalTask: Semantic search execution
- ReasoningTask: Answer synthesis
- ValidationTask: Quality assurance

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

from .planning_task import (
    PlanningTask,
    create_planning_task,
    get_planning_task_config,
    validate_planning_output,
    extract_search_params
)

from .retrieval_task import (
    RetrievalTask,
    create_retrieval_task,
    get_retrieval_task_config,
    validate_retrieval_output,
    extract_chunks,
    get_retrieval_confidence,
    get_retrieval_stats
)

from .reasoning_task import (
    ReasoningTask,
    create_reasoning_task,
    get_reasoning_task_config,
    validate_reasoning_output,
    extract_answer_and_metadata,
    count_citations,
    get_unique_sources
)

from .validation_task import (
    ValidationTask,
    create_validation_task,
    get_validation_task_config,
    validate_validation_output,
    is_approved,
    get_quality_scores,
    get_issues,
    get_enhanced_answer
)

__all__ = [
    # Task Classes
    'PlanningTask',
    'RetrievalTask',
    'ReasoningTask',
    'ValidationTask',
    
    # Creation Functions
    'create_planning_task',
    'create_retrieval_task',
    'create_reasoning_task',
    'create_validation_task',
    
    # Configuration Helpers
    'get_planning_task_config',
    'get_retrieval_task_config',
    'get_reasoning_task_config',
    'get_validation_task_config',
    
    # Validation Functions
    'validate_planning_output',
    'validate_retrieval_output',
    'validate_reasoning_output',
    'validate_validation_output',
    
    # Extraction Functions
    'extract_search_params',
    'extract_chunks',
    'extract_answer_and_metadata',
    'get_retrieval_confidence',
    'get_retrieval_stats',
    'count_citations',
    'get_unique_sources',
    'is_approved',
    'get_quality_scores',
    'get_issues',
    'get_enhanced_answer'
]

__version__ = '1.0.0'
