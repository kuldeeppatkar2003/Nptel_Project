"""
Validation Task for NPTEL Agentic RAG System
=============================================

The Validation Task is executed by the Validator Agent.
It verifies answer quality and enhances citations.

Output: Validated answer with enhanced citations or rejection report

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
from typing import Dict, Any, Optional
from crewai import Task

logger = logging.getLogger(__name__)


class ValidationTask:
    """
    Validation Task - Quality Assurance
    
    This task is assigned to the Validator Agent.
    
    Inputs:
    - Generated answer (from reasoning task)
    - Source chunks (from retrieval task)
    
    Outputs:
    - Validation status (APPROVED/NEEDS_REVISION)
    - Enhanced answer with clickable links
    - Quality scores
    - Issues found (if any)
    
    This is the FINAL checkpoint before delivery.
    
    Example:
        >>> from agents.validator_agent import create_validator_agent
        >>> validator = create_validator_agent(llm)
        >>> task = ValidationTask.create_task(
        ...     reasoning_output=answer,
        ...     retrieval_output=chunks,
        ...     agent=validator
        ... )
    """
    
    @staticmethod
    def create_task(
        reasoning_output: str,
        retrieval_output: str,
        agent = None,
        strict_mode: bool = True,
        verbose: bool = True
    ) -> Task:
        """
        Create a validation task.
        
        Args:
            reasoning_output: Output from reasoning task
            retrieval_output: Output from retrieval task (for verification)
            agent: Validator agent instance
            strict_mode: Enable strict validation criteria
            verbose: Enable verbose output
        
        Returns:
            Configured Task object
        """
        
        from llm.prompts import format_validation_prompt
        
        # Format the task description
        description = format_validation_prompt(
            reasoning_output,
            retrieval_output
        )
        
        # Add strict mode notice
        if strict_mode:
            description += """

**STRICT MODE ENABLED:**
Reject if ANY of these occur:
- Unsupported claim found
- Citation coverage < 100%
- Hallucination detected
- Quality score < 0.7
"""
        
        # Expected output structure
        expected_output = """JSON object containing:
{
    "validation_status": "APPROVED|NEEDS_REVISION",
    "verified_claims": N,
    "unsupported_claims": ["claim1", "claim2"],
    "citation_coverage": "XX%",
    "hallucinations_detected": N,
    "quality_scores": {
        "completeness": 0.XX,
        "clarity": 0.XX,
        "accuracy": 0.XX
    },
    "issues_found": ["issue1", "issue2"],
    "enhanced_answer": "Answer with clickable links...",
    "source_materials": [
        {
            "source_id": 1,
            "lecture_title": "...",
            "pdf_url": "...",
            "video_url": "..."
        }
    ]
}"""
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            
            # Task configuration
            async_execution=False,
            
            # Context from previous tasks
            context=[],
        )
        
        if verbose:
            logger.info(f"Created Validation Task (strict_mode={strict_mode})")
        
        return task
    
    @staticmethod
    def create_simple_validation_task(
        answer: str,
        sources: str,
        agent = None
    ) -> Task:
        """
        Create a simplified validation task.
        
        Args:
            answer: Generated answer to validate
            sources: Source chunks (JSON or text)
            agent: Validator agent
        
        Returns:
            Task object
        """
        
        description = f"""Validate this answer against source chunks:

**GENERATED ANSWER:**
{answer}

**SOURCE CHUNKS:**
{sources}

**VALIDATION CHECKS:**
1. Every claim in answer is in sources? (Yes/No)
2. All claims have [Source X] citations? (Yes/No)
3. Any hallucinations detected? (Yes/No)
4. Overall quality score (0-1)

**OUTPUT:**
- validation_status: APPROVED or NEEDS_REVISION
- issues_found: List of any problems
- enhanced_answer: Answer with clickable source links"""
        
        expected_output = "JSON with validation results"
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            async_execution=False
        )
        
        return task
    
    @staticmethod
    def create_citation_enhancement_task(
        answer: str,
        source_metadata: str,
        agent = None
    ) -> Task:
        """
        Create task focused on citation enhancement only.
        
        Args:
            answer: Answer with basic [Source X] citations
            source_metadata: Metadata with URLs
            agent: Validator agent
        
        Returns:
            Task object
        """
        
        description = f"""Enhance citations in this answer with clickable links:

**ANSWER:**
{answer}

**SOURCE METADATA (with URLs):**
{source_metadata}

**INSTRUCTIONS:**
1. Convert [Source X] to clickable markdown links
2. Format: [Source X - Lecture Title](PDF_URL)
3. Add "Source Materials" section at end
4. List all sources with links to PDFs and videos

Output enhanced answer."""
        
        expected_output = "Enhanced answer with clickable citations"
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            async_execution=False
        )
        
        return task


def create_validation_task(
    reasoning_output: str,
    retrieval_output: str,
    agent = None,
    strict_mode: bool = True,
    verbose: bool = True
) -> Task:
    """
    Convenience function to create validation task.
    
    Args:
        reasoning_output: Reasoning task output
        retrieval_output: Retrieval task output
        agent: Validator agent instance
        strict_mode: Enable strict validation
        verbose: Enable verbose logging
    
    Returns:
        Configured Task
    
    Example:
        >>> task = create_validation_task(
        ...     reasoning_output=answer_json,
        ...     retrieval_output=chunks_json,
        ...     agent=validator_agent,
        ...     strict_mode=True
        ... )
    """
    return ValidationTask.create_task(
        reasoning_output=reasoning_output,
        retrieval_output=retrieval_output,
        agent=agent,
        strict_mode=strict_mode,
        verbose=verbose
    )


# ============================================================================
# TASK CONFIGURATION HELPERS
# ============================================================================

def get_validation_task_config() -> Dict[str, Any]:
    """
    Get configuration for validation task.
    
    Returns:
        Dict with task configuration
    """
    return {
        "task_name": "Answer Validation",
        "agent_required": "ValidatorAgent",
        "execution_mode": "synchronous",
        "inputs": ["reasoning_output", "retrieval_output"],
        "outputs": [
            "validation_status",
            "quality_scores",
            "enhanced_answer",
            "issues_found"
        ],
        "expected_duration_seconds": 8,
        "dependencies": ["planning_task", "retrieval_task", "reasoning_task"],
        "is_final_gate": True,
        "strict_mode_default": True
    }


def validate_validation_output(output: str) -> Dict[str, Any]:
    """
    Validate the validation task output (meta-validation!).
    
    Args:
        output: Validation task output
    
    Returns:
        Dict with validation results
    """
    import json
    
    validation = {
        'is_json': False,
        'has_status': False,
        'has_scores': False,
        'valid': False
    }
    
    try:
        data = json.loads(output)
        validation['is_json'] = True
        
        # Check for required fields
        if 'validation_status' in data:
            validation['has_status'] = True
        
        if 'quality_scores' in data:
            validation['has_scores'] = True
        
        # Overall validation
        validation['valid'] = (
            validation['is_json'] and
            validation['has_status']
        )
        
    except json.JSONDecodeError:
        logger.error("Validation output is not valid JSON")
    
    return validation


def is_approved(validation_output: str) -> bool:
    """
    Check if answer was approved.
    
    Args:
        validation_output: Validation task output (JSON)
    
    Returns:
        True if APPROVED, False otherwise
    """
    import json
    
    try:
        data = json.loads(validation_output)
        status = data.get('validation_status', 'NEEDS_REVISION')
        return status == 'APPROVED'
        
    except Exception as e:
        logger.error(f"Failed to check approval: {e}")
        return False


def get_quality_scores(validation_output: str) -> Dict[str, float]:
    """
    Extract quality scores from validation output.
    
    Args:
        validation_output: Validation task output (JSON)
    
    Returns:
        Dict with quality scores
    """
    import json
    
    try:
        data = json.loads(validation_output)
        return data.get('quality_scores', {})
        
    except Exception as e:
        logger.error(f"Failed to get quality scores: {e}")
        return {}


def get_issues(validation_output: str) -> list:
    """
    Extract issues found during validation.
    
    Args:
        validation_output: Validation task output (JSON)
    
    Returns:
        List of issues
    """
    import json
    
    try:
        data = json.loads(validation_output)
        return data.get('issues_found', [])
        
    except Exception as e:
        logger.error(f"Failed to get issues: {e}")
        return []


def get_enhanced_answer(validation_output: str) -> str:
    """
    Extract enhanced answer with clickable links.
    
    Args:
        validation_output: Validation task output (JSON)
    
    Returns:
        Enhanced answer string
    """
    import json
    
    try:
        data = json.loads(validation_output)
        return data.get('enhanced_answer', '')
        
    except Exception as e:
        logger.error(f"Failed to get enhanced answer: {e}")
        return ''


if __name__ == "__main__":
    # Test task creation
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Validation Task creation...")
    
    # Create a mock agent
    from agents.validator_agent import create_validator_agent
    from langchain_community.llms import Ollama
    
    llm = Ollama(model="mistral", temperature=0.1)
    validator = create_validator_agent(llm, strict_mode=True)
    
    # Mock inputs
    mock_reasoning = """FCFS is the simplest scheduling algorithm [Source 1].
It executes processes in arrival order [Source 1]."""
    
    mock_retrieval = """{
        "chunks": [
            {
                "content": "FCFS is the simplest scheduling algorithm. It executes in arrival order.",
                "metadata": {"course_name": "OS", "lecture_no": 15}
            }
        ]
    }"""
    
    # Create task
    task = create_validation_task(
        reasoning_output=mock_reasoning,
        retrieval_output=mock_retrieval,
        agent=validator,
        strict_mode=True,
        verbose=True
    )
    
    print(f"\n✅ Validation Task created!")
    print(f"Description length: {len(task.description)} chars")
    
    # Show configuration
    print(f"\nTask configuration:")
    config = get_validation_task_config()
    for key, value in config.items():
        print(f"  {key}: {value}")
    
    # Test with mock output
    mock_output = """{
        "validation_status": "APPROVED",
        "verified_claims": 2,
        "unsupported_claims": [],
        "citation_coverage": "100%",
        "hallucinations_detected": 0,
        "quality_scores": {
            "completeness": 0.95,
            "clarity": 0.90,
            "accuracy": 1.0
        },
        "issues_found": [],
        "enhanced_answer": "FCFS is... [with links]"
    }"""
    
    validation = validate_validation_output(mock_output)
    print(f"\nMock output validation:")
    for key, value in validation.items():
        print(f"  {key}: {value}")
    
    # Test extraction functions
    print(f"\nExtracted data:")
    print(f"  Approved: {is_approved(mock_output)}")
    print(f"  Quality scores: {get_quality_scores(mock_output)}")
    print(f"  Issues: {get_issues(mock_output)}")
    print(f"  Has enhanced answer: {len(get_enhanced_answer(mock_output)) > 0}")
