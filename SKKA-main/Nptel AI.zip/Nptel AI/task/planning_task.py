"""
Planning Task for NPTEL Agentic RAG System
===========================================

The Planning Task is executed by the Planner Agent.
It analyzes student queries and creates optimal retrieval strategies.

Output: Structured plan with query analysis and retrieval recommendations

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
from typing import Dict, Any, Optional
from crewai import Task

logger = logging.getLogger(__name__)


class PlanningTask:
    """
    Planning Task - Query Analysis & Strategy Creation
    
    This task is assigned to the Planner Agent.
    
    Inputs:
    - Student query
    - Optional context (course, week, etc.)
    
    Outputs:
    - Query classification
    - Complexity assessment
    - Sub-queries (if needed)
    - Retrieval strategy
    - Recommended filters
    
    Example:
        >>> from agents.planner_agent import create_planner_agent
        >>> planner = create_planner_agent(llm)
        >>> task = PlanningTask.create_task(
        ...     query="What is FCFS?",
        ...     context={},
        ...     agent=planner
        ... )
    """
    
    @staticmethod
    def create_task(
        query: str,
        context: Optional[Dict[str, Any]] = None,
        agent = None,
        verbose: bool = True
    ) -> Task:
        """
        Create a planning task.
        
        Args:
            query: Student's question
            context: Optional context dict (course, week, etc.)
            agent: Planner agent instance
            verbose: Enable verbose output
        
        Returns:
            Configured Task object
        """
        
        from llm.prompts import format_planning_prompt
        
        # Format the task description with query and context
        task_context = context or {}
        description = format_planning_prompt(query, task_context)
        
        # Expected output structure
        expected_output = """JSON object containing:
{
    "query_type": "factual|conceptual|comparison|procedural|multi-step",
    "complexity": "low|medium|high",
    "domain": "subject area",
    "key_concepts": ["concept1", "concept2"],
    "sub_queries": ["sub1", "sub2"],
    "estimated_chunks_needed": N,
    "recommended_filters": {
        "course_name": "...",
        "week_no": X
    },
    "search_strategy": "single_query|multi_query|iterative_refinement",
    "expected_answer_type": "definition|explanation|comparison|step-by-step",
    "reasoning": "Brief explanation of strategy"
}"""
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            
            # Task configuration
            async_execution=False,  # Execute synchronously
        )
        
        if verbose:
            logger.info(f"Created Planning Task for query: {query[:50]}...")
        
        return task
    
    @staticmethod
    def create_simple_planning_task(
        query: str,
        agent = None
    ) -> Task:
        """
        Create a simplified planning task (minimal context).
        
        Args:
            query: Student's question
            agent: Planner agent
        
        Returns:
            Task object
        """
        
        description = f"""Analyze this student query and create a retrieval strategy:

**QUERY:** {query}

Provide:
1. Query type and complexity
2. Key concepts to search for
3. How many chunks needed (3-15)
4. Recommended search strategy

Output as JSON."""
        
        expected_output = "JSON with query analysis and retrieval strategy"
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            async_execution=False
        )
        
        return task


def create_planning_task(
    query: str,
    context: Optional[Dict[str, Any]] = None,
    agent = None,
    verbose: bool = True
) -> Task:
    """
    Convenience function to create planning task.
    
    Args:
        query: Student's question
        context: Optional context
        agent: Planner agent instance
        verbose: Enable verbose logging
    
    Returns:
        Configured Task
    
    Example:
        >>> task = create_planning_task(
        ...     query="Explain deadlock prevention",
        ...     context={"course": "Operating Systems"},
        ...     agent=planner_agent
        ... )
    """
    return PlanningTask.create_task(
        query=query,
        context=context,
        agent=agent,
        verbose=verbose
    )


# ============================================================================
# TASK CONFIGURATION HELPERS
# ============================================================================

def get_planning_task_config() -> Dict[str, Any]:
    """
    Get configuration for planning task.
    
    Returns:
        Dict with task configuration
    """
    return {
        "task_name": "Query Planning",
        "agent_required": "PlannerAgent",
        "execution_mode": "synchronous",
        "inputs": ["query", "context (optional)"],
        "outputs": [
            "query_type",
            "complexity",
            "sub_queries",
            "estimated_chunks_needed",
            "recommended_filters",
            "search_strategy"
        ],
        "expected_duration_seconds": 5,
        "dependencies": []
    }


def validate_planning_output(output: str) -> bool:
    """
    Validate that planning task output is properly structured.
    
    Args:
        output: Task output string
    
    Returns:
        True if valid, False otherwise
    """
    import json
    
    try:
        # Try to parse as JSON
        data = json.loads(output)
        
        # Check required fields
        required_fields = [
            'query_type',
            'complexity',
            'estimated_chunks_needed'
        ]
        
        for field in required_fields:
            if field not in data:
                logger.warning(f"Planning output missing field: {field}")
                return False
        
        return True
        
    except json.JSONDecodeError:
        logger.error("Planning output is not valid JSON")
        return False


def extract_search_params(planning_output: str) -> Dict[str, Any]:
    """
    Extract search parameters from planning output.
    
    Args:
        planning_output: JSON string from planning task
    
    Returns:
        Dict with search parameters
    """
    import json
    
    try:
        data = json.loads(planning_output)
        
        return {
            'k': data.get('estimated_chunks_needed', 10),
            'filters': data.get('recommended_filters', {}),
            'strategy': data.get('search_strategy', 'single_query'),
            'sub_queries': data.get('sub_queries', [])
        }
        
    except Exception as e:
        logger.error(f"Failed to extract search params: {e}")
        return {
            'k': 10,
            'filters': {},
            'strategy': 'single_query',
            'sub_queries': []
        }


if __name__ == "__main__":
    # Test task creation
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Planning Task creation...")
    
    # Create a mock agent (in real usage, use actual PlannerAgent)
    from agents.planner_agent import create_planner_agent
    from langchain_community.llms import Ollama
    
    llm = Ollama(model="mistral", temperature=0.1)
    planner = create_planner_agent(llm)
    
    # Create task
    test_query = "What is the convoy effect in FCFS scheduling?"
    test_context = {"course": "Operating Systems", "week": 5}
    
    task = create_planning_task(
        query=test_query,
        context=test_context,
        agent=planner,
        verbose=True
    )
    
    print(f"\n✅ Planning Task created!")
    print(f"Description length: {len(task.description)} chars")
    print(f"Expected output: {task.expected_output[:100]}...")
    
    # Show configuration
    print(f"\nTask configuration:")
    config = get_planning_task_config()
    for key, value in config.items():
        print(f"  {key}: {value}")
    
    # Test validation (with mock output)
    mock_output = """{
        "query_type": "explanation",
        "complexity": "medium",
        "estimated_chunks_needed": 8
    }"""
    
    is_valid = validate_planning_output(mock_output)
    print(f"\nMock output validation: {'✅ PASS' if is_valid else '❌ FAIL'}")
