"""
Retrieval Task for NPTEL Agentic RAG System
============================================

The Retrieval Task is executed by the Retriever Agent.
It performs semantic search based on the Planner's strategy.

Output: Retrieved chunks with metadata and confidence scores

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
from typing import Dict, Any, Optional, List
from crewai import Task

logger = logging.getLogger(__name__)


class RetrievalTask:
    """
    Retrieval Task - Semantic Search Execution
    
    This task is assigned to the Retriever Agent.
    
    Inputs:
    - Original query
    - Planning output (strategy, filters, k)
    
    Outputs:
    - Retrieved chunks with content and metadata
    - Similarity scores
    - Retrieval confidence (HIGH/MEDIUM/LOW)
    - Search log
    
    Example:
        >>> from agents.retriever_agent import create_retriever_agent
        >>> retriever = create_retriever_agent(llm, tools=[chromadb_tool])
        >>> task = RetrievalTask.create_task(
        ...     query="What is FCFS?",
        ...     planning_output=planning_result,
        ...     agent=retriever
        ... )
    """
    
    @staticmethod
    def create_task(
        query: str,
        planning_output: str,
        agent = None,
        context: Optional[Dict[str, Any]] = None,
        verbose: bool = True
    ) -> Task:
        """
        Create a retrieval task.
        
        Args:
            query: Original student question
            planning_output: Output from planning task (JSON)
            agent: Retriever agent instance
            context: Optional additional context
            verbose: Enable verbose output
        
        Returns:
            Configured Task object
        """
        
        from llm.prompts import format_retrieval_prompt
        
        # Format the task description
        description = format_retrieval_prompt(query, planning_output)
        
        # Add context if provided
        if context:
            description += f"\n\n**ADDITIONAL CONTEXT:**\n{context}"
        
        # Expected output structure
        expected_output = """JSON object containing:
{
    "chunks": [
        {
            "chunk_id": N,
            "content": "lecture content...",
            "metadata": {
                "course_name": "...",
                "lecture_no": X,
                "week_no": Y,
                "similarity_score": 0.XX
            }
        }
    ],
    "total_retrieved": N,
    "avg_similarity": 0.XX,
    "retrieval_confidence": "HIGH|MEDIUM|LOW",
    "unique_sources": N,
    "refinement_attempts": N,
    "search_log": ["query1: k results", "query2: k results"]
}"""
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            
            # Task configuration
            async_execution=False,
            
            # Context from previous task
            context=[],  # Will be populated by CrewAI
        )
        
        if verbose:
            logger.info(f"Created Retrieval Task for query: {query[:50]}...")
        
        return task
    
    @staticmethod
    def create_simple_retrieval_task(
        query: str,
        k: int = 10,
        agent = None
    ) -> Task:
        """
        Create a simplified retrieval task (no planning output).
        
        Args:
            query: Student's question
            k: Number of chunks to retrieve
            agent: Retriever agent
        
        Returns:
            Task object
        """
        
        description = f"""Execute semantic search for this query:

**QUERY:** {query}

**INSTRUCTIONS:**
1. Use chromadb_search tool
2. Retrieve k={k} most relevant chunks
3. Check similarity scores (>0.7 = high confidence)
4. Return chunks with metadata

Output as JSON with chunks array."""
        
        expected_output = "JSON with retrieved chunks and metadata"
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            async_execution=False
        )
        
        return task
    
    @staticmethod
    def create_filtered_retrieval_task(
        query: str,
        filters: Dict[str, Any],
        k: int = 10,
        agent = None
    ) -> Task:
        """
        Create retrieval task with specific filters.
        
        Args:
            query: Student's question
            filters: Metadata filters (course_name, week_no, etc.)
            k: Number of chunks
            agent: Retriever agent
        
        Returns:
            Task object
        """
        
        description = f"""Execute FILTERED semantic search:

**QUERY:** {query}

**FILTERS:** {filters}

**INSTRUCTIONS:**
1. Use chromadb_search tool
2. Pass filter values as arguments: course_name, week_no, lecture_no
3. Retrieve k={k} chunks
4. Assess quality (avg similarity score)
5. If low quality, try broader search

Output as JSON."""
        
        expected_output = "JSON with filtered search results"
        
        task = Task(
            description=description,
            expected_output=expected_output,
            agent=agent,
            async_execution=False
        )
        
        return task


def create_retrieval_task(
    query: str,
    planning_output: str,
    agent = None,
    context: Optional[Dict[str, Any]] = None,
    verbose: bool = True
) -> Task:
    """
    Convenience function to create retrieval task.
    
    Args:
        query: Student's question
        planning_output: Planning task output (JSON)
        agent: Retriever agent instance
        context: Optional additional context
        verbose: Enable verbose logging
    
    Returns:
        Configured Task
    
    Example:
        >>> task = create_retrieval_task(
        ...     query="Explain deadlock",
        ...     planning_output=planning_json,
        ...     agent=retriever_agent
        ... )
    """
    return RetrievalTask.create_task(
        query=query,
        planning_output=planning_output,
        agent=agent,
        context=context,
        verbose=verbose
    )


# ============================================================================
# TASK CONFIGURATION HELPERS
# ============================================================================

def get_retrieval_task_config() -> Dict[str, Any]:
    """
    Get configuration for retrieval task.
    
    Returns:
        Dict with task configuration
    """
    return {
        "task_name": "Semantic Retrieval",
        "agent_required": "RetrieverAgent",
        "execution_mode": "synchronous",
        "inputs": ["query", "planning_output"],
        "outputs": [
            "chunks",
            "similarity_scores",
            "retrieval_confidence",
            "search_log"
        ],
        "expected_duration_seconds": 8,
        "dependencies": ["planning_task"],
        "required_tools": ["chromadb_search"]
    }


def validate_retrieval_output(output: str) -> bool:
    """
    Validate that retrieval task output is properly structured.
    
    Args:
        output: Task output string
    
    Returns:
        True if valid, False otherwise
    """
    import json
    
    try:
        data = json.loads(output)
        
        # Check required fields
        if 'chunks' not in data:
            logger.warning("Retrieval output missing 'chunks'")
            return False
        
        if not isinstance(data['chunks'], list):
            logger.warning("'chunks' is not a list")
            return False
        
        # Check chunk structure
        if len(data['chunks']) > 0:
            first_chunk = data['chunks'][0]
            required_chunk_fields = ['content', 'metadata']
            
            for field in required_chunk_fields:
                if field not in first_chunk:
                    logger.warning(f"Chunk missing field: {field}")
                    return False
        
        return True
        
    except json.JSONDecodeError:
        logger.error("Retrieval output is not valid JSON")
        return False


def extract_chunks(retrieval_output: str) -> List[Dict[str, Any]]:
    """
    Extract chunks from retrieval output.
    
    Args:
        retrieval_output: JSON string from retrieval task
    
    Returns:
        List of chunk dicts
    """
    import json
    
    try:
        data = json.loads(retrieval_output)
        return data.get('chunks', [])
        
    except Exception as e:
        logger.error(f"Failed to extract chunks: {e}")
        return []


def get_retrieval_confidence(retrieval_output: str) -> str:
    """
    Get confidence level from retrieval output.
    
    Args:
        retrieval_output: JSON string from retrieval task
    
    Returns:
        Confidence level: HIGH, MEDIUM, or LOW
    """
    import json
    
    try:
        data = json.loads(retrieval_output)
        return data.get('retrieval_confidence', 'MEDIUM')
        
    except Exception as e:
        logger.error(f"Failed to get confidence: {e}")
        return 'LOW'


def get_retrieval_stats(retrieval_output: str) -> Dict[str, Any]:
    """
    Get statistics from retrieval output.
    
    Args:
        retrieval_output: JSON string from retrieval task
    
    Returns:
        Dict with stats
    """
    import json
    
    try:
        data = json.loads(retrieval_output)
        
        return {
            'total_retrieved': data.get('total_retrieved', 0),
            'avg_similarity': data.get('avg_similarity', 0.0),
            'confidence': data.get('retrieval_confidence', 'UNKNOWN'),
            'unique_sources': data.get('unique_sources', 0),
            'refinements': data.get('refinement_attempts', 0)
        }
        
    except Exception as e:
        logger.error(f"Failed to get stats: {e}")
        return {}


if __name__ == "__main__":
    # Test task creation
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Retrieval Task creation...")
    
    # Create a mock agent
    from agents.retriever_agent import create_retriever_agent
    from langchain_community.llms import Ollama
    
    llm = Ollama(model="mistral", temperature=0.1)
    
    # Note: In real usage, pass chromadb_tool
    print("\nNote: Creating without tools for demo")
    retriever = create_retriever_agent(llm, tools=[], verbose=False)
    
    # Mock planning output
    planning_output = """{
        "query_type": "explanation",
        "estimated_chunks_needed": 8,
        "recommended_filters": {"course_name": "Operating Systems"}
    }"""
    
    # Create task
    test_query = "What is the convoy effect?"
    
    task = create_retrieval_task(
        query=test_query,
        planning_output=planning_output,
        agent=retriever,
        verbose=True
    )
    
    print(f"\n✅ Retrieval Task created!")
    print(f"Description length: {len(task.description)} chars")
    
    # Show configuration
    print(f"\nTask configuration:")
    config = get_retrieval_task_config()
    for key, value in config.items():
        print(f"  {key}: {value}")
    
    # Test validation (with mock output)
    mock_output = """{
        "chunks": [
            {
                "content": "Test content",
                "metadata": {"course_name": "OS", "lecture_no": 15}
            }
        ],
        "total_retrieved": 1,
        "avg_similarity": 0.85,
        "retrieval_confidence": "HIGH"
    }"""
    
    is_valid = validate_retrieval_output(mock_output)
    print(f"\nMock output validation: {'✅ PASS' if is_valid else '❌ FAIL'}")
    
    # Test extraction
    chunks = extract_chunks(mock_output)
    confidence = get_retrieval_confidence(mock_output)
    stats = get_retrieval_stats(mock_output)
    
    print(f"\nExtracted data:")
    print(f"  Chunks: {len(chunks)}")
    print(f"  Confidence: {confidence}")
    print(f"  Stats: {stats}")
