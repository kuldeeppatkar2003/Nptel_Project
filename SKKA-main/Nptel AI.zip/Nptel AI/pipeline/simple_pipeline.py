import logging
import json
from typing import Dict, Any, List

from llm.mistral_wrapper import create_mistral_llm
from retriever import ChromaDBRetriever, RetrieverConfig

logger = logging.getLogger(__name__)

class SimplePipeline:
    def __init__(self):
        # 1. Initialize LLM (Wrapper handles Ollama vs Groq internally)
        import os
        model_name = os.getenv("LLM_MODEL")
        self.llm = create_mistral_llm(model_name=model_name) 
        
        # 2. Initialize Retriever
        self.retriever = ChromaDBRetriever()
        
    def execute(self, query: str) -> Dict[str, Any]:
        """
        Execute the RAG pipeline step-by-step.
        
        Steps:
        1. PLAN: Analyze query
        2. RETRIEVE: Get chunks
        3. REASON: Generate answer
        4. VALIDATE: Check quality
        """
        results = {
            "query": query,
            "status": "PROCESSING",
            "steps": []
        }
        
        # --- STEP 1: PLANNER ---
        logger.info(f"PLANNER: Analyzing '{query}'")
        # For simple queries, we can skip complex planning or just pass-through
        # But let's refine the query if needed. For now, pass-through.
        refined_query = query 
        results["steps"].append({"agent": "Planner", "status": "Done"})
        
        # --- STEP 2: RETRIEVER ---
        logger.info("RETRIEVER: Searching database...")
        chunks = self.retriever.search(query=refined_query, k=5)
        
        # DEBUG: Print first chunk content
        if chunks:
            logger.info(f"DEBUG CHUNK 0 CONTENT: {chunks[0].get('content', 'NO CONTENT')[:200]}")
        else:
            logger.info("DEBUG: No chunks found.")
            
        results["retrieved_chunks"] = chunks
        results["steps"].append({"agent": "Retriever", "status": "Done", "count": len(chunks)})
        
        if not chunks:
            return {
                "status": "FAILED",
                "answer": "I could not find any relevant information in the lecture database.",
                "steps": results["steps"]
            }

        # --- STEP 3: REASONING ---
        logger.info("REASONING: Generating answer...")
        answer = self.llm.generate_grounded_response(refined_query, chunks)
        results["answer"] = answer
        results["steps"].append({"agent": "Reasoning", "status": "Done"})
        
        # --- STEP 4: VALIDATOR ---
        logger.info("VALIDATOR: Checking answer...")
        # Simple validation: Check if citations exist
        if "[Source" in answer:
            validation_status = "APPROVED"
        else:
            validation_status = "NEEDS_REVISION"
            
        results["status"] = validation_status
        results["steps"].append({"agent": "Validator", "status": validation_status})
        
        return results

# Singleton for easy import
def create_pipeline():
    return SimplePipeline()
