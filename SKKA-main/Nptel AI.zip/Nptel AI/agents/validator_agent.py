"""
Validator Agent for NPTEL Agentic RAG System
=============================================

The Validator Agent performs quality assurance on generated answers.

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from crewai import Agent, Task

logger = logging.getLogger(__name__)


# ============================================================================
# AGENT CONFIGURATION
# ============================================================================

@dataclass
class ValidatorAgentConfig:
    """Configuration for Validator Agent"""
    
    role: str = "Answer Quality Auditor"
    
    goal: str = """Verify that generated answers are accurate, fully supported by 
    source material, and properly cited. Enhance answers with clickable source 
    references before delivery to students."""
    
    backstory: str = """You are a meticulous academic reviewer."""
    
    verbose: bool = True
    allow_delegation: bool = False
    max_iter: int = 3
    strict_mode: bool = True


# ============================================================================
# SYSTEM PROMPT
# ============================================================================

VALIDATOR_SYSTEM_PROMPT = """You are an Answer Quality Auditor for NPTEL course answers.

YOUR ROLE: Final quality gate before delivering answers to students.

YOUR TASK:
Validate the generated answer against source chunks and enhance with URLs.

VALIDATION CHECKLIST:

1. ✓ CLAIM VERIFICATION
   - Extract each factual claim from the answer
   - Cross-reference against source chunks
   - Mark each claim as:
     * SUPPORTED: Found in chunks
     * UNSUPPORTED: Not in chunks (HALLUCINATION)
     * PARTIAL: Partially supported

2. ✓ CITATION COMPLETENESS
   - Count total factual claims in answer
   - Count citations present
   - Coverage = (citations / claims) × 100%
   - Target: 100% coverage

3. ✓ CITATION ACCURACY
   - Verify each citation points to correct lecture
   - Check lecture number matches content
   - Ensure lecture exists in retrieved chunks

4. ✓ HALLUCINATION DETECTION
   - Flag any statements not in source chunks
   - Risk levels:
     * LOW: All claims supported
     * MEDIUM: Minor unsupported details
     * HIGH: Major claims unsupported

5. ✓ QUALITY SCORING
   - Completeness: Does answer fully address query? (0-1)
   - Clarity: Is explanation easy to understand? (0-1)
   - Accuracy: All claims verifiable? (0-1)
   - Overall: Average of above

6. ✓ ENHANCEMENT
   - Add clickable URLs to citations
   - Format: [Lecture X: Title](URL)
   - Create "Sources" section at end

VALIDATION OUTPUT FORMAT:

VALIDATION REPORT:
{
  "status": "APPROVED" | "NEEDS_REVISION",
  "citation_coverage": 95,  # percentage
  "quality_score": 0.85,    # 0.0-1.0
  "hallucination_risk": "LOW" | "MEDIUM" | "HIGH",
  "issues_found": [
    "Claim 'X' lacks citation",
    "Statement about Y not found in chunks"
  ],
  "supported_claims": 18,
  "unsupported_claims": 1,
  "total_claims": 19
}

ENHANCED ANSWER:
[Original answer with clickable URLs added]

## Sources
[1] Lecture 3: Ascent Mission Basics (Prof. Ashok Joshi, IIT Bombay)
    📄 [View Transcript](https://nptel.ac.in/courses/101101086/3)
    🎥 [Watch Video](https://nptel.ac.in/courses/101101086)

APPROVAL CRITERIA (Strict Mode):

✓ APPROVED if ALL of:
- Citation coverage = 100%
- Hallucination risk = LOW
- Quality score ≥ 0.7
- No unsupported claims

✗ NEEDS_REVISION if ANY of:
- Citation coverage < 100%
- Hallucination risk = MEDIUM or HIGH
- Quality score < 0.7
- Unsupported claims found

EXAMPLES:

Example 1 - APPROVED:
Answer: "Thrust is the force that propels rockets [Lecture 3: Ascent Mission]. 
It equals mass flow rate times exhaust velocity [Lecture 3: Ascent Mission]."
Chunks: Contains both statements
Result: APPROVED (100% coverage, LOW risk, 0.9 quality)

Example 2 - NEEDS_REVISION:
Answer: "Thrust propels rockets. Typically, rocket engines achieve 95% efficiency."
Chunks: First sentence present, efficiency number NOT in chunks
Issues: 
- "95% efficiency" is UNSUPPORTED (hallucination)
- Missing citation on first sentence
Result: NEEDS_REVISION (50% coverage, HIGH risk, 0.5 quality)
Feedback: "Remove unsupported efficiency claim. Add citation to first sentence."

Example 3 - PARTIAL INFO (but APPROVED):
Answer: "The lectures discuss thrust as a propulsion force [Lecture 3]. 
However, specific efficiency values are not provided in the available content."
Chunks: General thrust discussion, no efficiency data
Result: APPROVED (honest about limitations, 100% coverage, 0.8 quality)

URL FORMAT:
Base: https://nptel.ac.in/courses/{course_id}
Lecture: https://nptel.ac.in/courses/{course_id}/{lecture_no}

Example metadata:
{
  "course_url": "https://nptel.ac.in/courses/101101086",
  "lecture_no": 3
}
Enhanced citation:
[Lecture 3: Ascent Mission](https://nptel.ac.in/courses/101101086/3)

IMPORTANT:
- Be strict but fair
- Provide specific, actionable feedback
- Preserve good content, only flag actual issues
- Enhance all approved answers with URLs
"""


# ============================================================================
# VALIDATOR AGENT CLASS
# ============================================================================

class ValidatorAgent:
    """
    Validator Agent - Quality Assurance & Citation Enhancement
    
    This is the final agent in the pipeline.
    """
    
    @staticmethod
    def create(
        llm,
        tools: List = None,
        config: Optional[ValidatorAgentConfig] = None,
        strict_mode: bool = True,
        verbose: bool = True
    ) -> Agent:
        """
        Create a Validator Agent instance.
        
        Args:
            llm: Language model instance
            tools: Optional list of validation tools
            config: Optional agent configuration
            strict_mode: Enable strict validation criteria
            verbose: Enable verbose output
        
        Returns:
            Configured CrewAI Agent
        """
        
        cfg = config or ValidatorAgentConfig()
        cfg.strict_mode = strict_mode
        
        backstory = VALIDATOR_SYSTEM_PROMPT
        if strict_mode:
            backstory += """

**STRICT VALIDATION MODE ENABLED:**

Rejection Criteria (ANY of these → NEEDS_REVISION):
- Citation coverage < 100%
- ANY unsupported claim found
- Hallucination risk ≠ LOW
- Quality score < 0.7

In strict mode: Quality > Speed
Better to request revision than deliver flawed answer.
"""
        
        agent = Agent(
            role=cfg.role,
            goal=cfg.goal,
            backstory=backstory,
            verbose=cfg.verbose if not verbose else True,
            allow_delegation=cfg.allow_delegation,
            llm=llm,
            tools=tools or [],
            max_iter=cfg.max_iter,
            memory=True
        )
        
        if verbose:
            logger.info(f"✓ Created Validator Agent (strict_mode={strict_mode})")
        
        return agent
    
    @staticmethod
    def create_task(
        agent: Agent,
        query: str,
        answer: str,
        chunks: List[Dict[str, Any]]
    ) -> Task:
        """
        Create a validation task for the agent.
        
        Args:
            agent: Validator agent instance
            query: Original query
            answer: Generated answer to validate
            chunks: Source chunks used
        
        Returns:
            CrewAI Task
        """
        
        # Format chunks for validation
        chunks_text = "\n\n".join([
            f"CHUNK {i+1} (Lecture {chunk.get('metadata', {}).get('lecture_no', '?')}):\n"
            f"{chunk.get('page_content', chunk.get('content', ''))}"
            for i, chunk in enumerate(chunks)
        ])
        
        # Extract metadata for URL generation
        metadata_info = []
        for chunk in chunks:
            meta = chunk.get('metadata', {})
            metadata_info.append({
                'lecture_no': meta.get('lecture_no'),
                'lecture_name': meta.get('lecture_name'),
                'course_url': meta.get('course_url', 'https://nptel.ac.in'),
                'professor': meta.get('professor'),
                'institute': meta.get('institute')
            })
        
        task_description = f"""Validate the generated answer and enhance with URLs.

ORIGINAL QUERY: "{query}"

GENERATED ANSWER:
{answer}

SOURCE CHUNKS:
{chunks_text}

METADATA FOR URL GENERATION:
{metadata_info}

YOUR VALIDATION TASKS:

1. VERIFY CLAIMS
   - Extract each factual claim from the answer
   - Check if claim is supported by chunks
   - Mark as SUPPORTED/UNSUPPORTED

2. CHECK CITATIONS
   - Count total claims
   - Count citations present
   - Calculate coverage percentage

3. DETECT HALLUCINATIONS
   - Flag any content not in chunks
   - Assess risk: LOW/MEDIUM/HIGH

4. SCORE QUALITY
   - Completeness (0-1)
   - Clarity (0-1)
   - Accuracy (0-1)
   - Overall average

5. MAKE DECISION
   - APPROVED: All criteria met
   - NEEDS_REVISION: Issues found (provide specific feedback)

6. ENHANCE (if approved)
   - Add clickable URLs to citations
   - Create Sources section
   - Format nicely

PROVIDE:
1. Validation Report (JSON format)
2. Enhanced Answer (if approved) OR Feedback (if needs revision)
"""
        
        task = Task(
            description=task_description,
            agent=agent,
            expected_output="Validation report with status, scores, issues, and enhanced answer (if approved)"
        )
        
        return task


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_validator_agent(
    llm,
    tools: List = None,
    strict_mode: bool = True,
    verbose: bool = True,
    **kwargs
) -> Agent:
    """
    Convenience function to create a Validator Agent.
    
    Args:
        llm: Language model instance
        tools: Optional validation tools
        strict_mode: Enable strict validation
        verbose: Enable verbose output
        **kwargs: Additional config parameters
    
    Returns:
        Configured Validator Agent
    
    Example:
        >>> from langchain_community.llms import Ollama
        >>> llm = Ollama(model="mistral", temperature=0.1)
        >>> validator = create_validator_agent(llm, strict_mode=True)
    """
    
    config_dict = {}
    for key in ['role', 'goal', 'backstory', 'max_iter']:
        if key in kwargs:
            config_dict[key] = kwargs[key]
    
    config_dict['verbose'] = verbose
    config_dict['strict_mode'] = strict_mode
    config = ValidatorAgentConfig(**config_dict)
    
    return ValidatorAgent.create(llm, tools, config, strict_mode, verbose)


def create_validation_task(
    agent: Agent,
    query: str,
    answer: str,
    chunks: List[Dict[str, Any]]
) -> Task:
    """
    Create validation task.
    
    Args:
        agent: Validator agent
        query: User query
        answer: Generated answer
        chunks: Source chunks
    
    Returns:
        Task for answer validation
    """
    return ValidatorAgent.create_task(agent, query, answer, chunks)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Validator Agent...")
    
    from langchain_community.llms import Ollama
    
    # Create LLM
    llm = Ollama(model="mistral", temperature=0.1)
    
    # Create agent
    validator = create_validator_agent(llm, strict_mode=True, verbose=True)
    print(f"✓ Created: {validator.role}")
    
    # Create test task
    test_query = "What is thrust?"
    test_answer = "Thrust is force [Lecture 3: Ascent]."
    test_chunks = [{"page_content": "Thrust is force that propels...", "metadata": {"lecture_no": 3}}]
    
    task = create_validation_task(validator, test_query, test_answer, test_chunks)
    print(f"✓ Created validation task")
    
    print("\n✓ Validator Agent ready!")
