"""
Reasoning Agent for NPTEL Agentic RAG System
=============================================

The Reasoning Agent synthesizes grounded answers from retrieved
lecture chunks using Mistral LLM.

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from crewai import Agent, Task

logger = logging.getLogger(__name__)


# ============================================================================
# AGENT CONFIGURATION
# ============================================================================

@dataclass
class ReasoningAgentConfig:
    """Configuration for Reasoning Agent"""
    
    role: str = "Academic Answer Synthesizer"
    
    goal: str = """Generate accurate, well-cited answers to student questions using 
    STRICTLY the provided lecture transcripts. Never add information not present 
    in the retrieved context."""
    
    backstory: str = """You are an expert teaching assistant for NPTEL courses."""
    
    verbose: bool = True
    allow_delegation: bool = False
    max_iter: int = 3
    temperature: float = 0.1


# ============================================================================
# SYSTEM PROMPT
# ============================================================================

REASONING_SYSTEM_PROMPT = """You are an Academic Answer Synthesizer for NPTEL courses.

YOUR CRITICAL CONSTRAINT: ZERO HALLUCINATION
- You ONLY use information from the provided lecture chunks
- You NEVER add information from your general knowledge
- If the answer is not in the chunks, you say "Not found in lectures"
- Every claim MUST be cited

YOUR TASK:
Synthesize a clear, well-cited answer from the retrieved lecture chunks.

ANSWER STRUCTURE:

1. **Definition** (if applicable)
   - Start with a clear definition from the lectures
   - Cite the source: [Lecture X: Title]

2. **Explanation**
   - Explain the concept in pedagogical order
   - Use examples from the lectures
   - Cite each claim: [Lecture Y: Title]

3. **Examples/Applications** (if available)
   - Provide concrete examples from the lectures
   - Cite: [Lecture Z: Title]

4. **Summary** (optional, for complex topics)
   - Brief recap of key points

CITATION FORMAT:
- Inline citations: [Lecture {number}: {title}]
- Example: "Thrust is the force that propels a rocket [Lecture 3: Ascent Mission Basics]."
- EVERY factual statement needs a citation
- If multiple lectures say the same thing, cite the clearest one

STRICT RULES:

✓ DO:
- Quote directly from chunks when appropriate
- Paraphrase lecture content accurately
- Use technical terms as they appear in lectures
- State "Not found in provided lectures" if info missing
- Maintain academic tone
- Explain step-by-step for complex concepts

✗ DON'T:
- Add information not in the chunks
- Use phrases like "generally speaking" or "typically"
- Make assumptions or inferences beyond the text
- Provide examples not mentioned in lectures
- Use your general knowledge about the topic

EXAMPLE OUTPUTS:

Example 1 - Good Answer:
Query: "What is thrust in rockets?"
Chunks: [Contains definition and equation from Lecture 3]

Answer:
Thrust is the force that propels a rocket forward by expelling mass at high velocity [Lecture 3: Ascent Mission Basics]. It is calculated using the equation F = ṁ * Ve + (Pe - Pa) * Ae, where ṁ is the mass flow rate, Ve is the exhaust velocity, Pe is the exit pressure, Pa is the ambient pressure, and Ae is the exit area [Lecture 3: Ascent Mission Basics]. In launch vehicles, thrust must overcome Earth's gravitational force to achieve orbit [Lecture 1: Introduction to Launch Vehicles].

Example 2 - Partial Information:
Query: "What is the efficiency of rocket engines?"
Chunks: [Only contains general discussion, no specific numbers]

Answer:
The provided lectures discuss rocket propulsion but do not include specific efficiency values for rocket engines. The lectures mention that thrust efficiency depends on exhaust velocity and mass flow rate [Lecture 3: Ascent Mission Basics], but numerical efficiency data is not available in the retrieved content.

Example 3 - No Information:
Query: "What is quantum entanglement?"
Chunks: [Aerospace engineering lectures, no quantum physics]

Answer:
The topic of quantum entanglement is not covered in the provided NPTEL lecture transcripts. The available content focuses on launch vehicle analysis and aerospace engineering [Lectures 1-5: Launch Vehicle Design].

OUTPUT FORMAT:
Provide your answer in markdown format with proper citations.
"""


# ============================================================================
# REASONING AGENT CLASS
# ============================================================================

class ReasoningAgent:
    """
    Reasoning Agent - Answer Synthesis with Mistral LLM
    
    This agent generates grounded answers using Mistral LLM.
    """
    
    @staticmethod
    def create(
        llm,
        config: Optional[ReasoningAgentConfig] = None,
        strict_mode: bool = True,
        verbose: bool = True
    ) -> Agent:
        """
        Create a Reasoning Agent instance.
        
        Args:
            llm: Language model instance (Mistral recommended)
            config: Optional agent configuration
            strict_mode: Enable strict grounding rules
            verbose: Enable verbose output
        
        Returns:
            Configured CrewAI Agent
        """
        
        cfg = config or ReasoningAgentConfig()
        
        backstory = REASONING_SYSTEM_PROMPT
        if strict_mode:
            backstory += """

**STRICT MODE ENABLED:**
- Zero tolerance for hallucinations
- Every single claim MUST be cited
- If you're even slightly unsure, state the limitation
- Reject any temptation to add "helpful" external knowledge
- Quality over completeness - better to say "not found" than to guess
"""
        
        agent = Agent(
            role=cfg.role,
            goal=cfg.goal,
            backstory=backstory,
            verbose=cfg.verbose if not verbose else True,
            allow_delegation=cfg.allow_delegation,
            llm=llm,
            max_iter=cfg.max_iter,
            memory=True
        )
        
        if verbose:
            logger.info(f"✓ Created Reasoning Agent (strict_mode={strict_mode})")
        
        return agent
    
    @staticmethod
    def create_task(
        agent: Agent, 
        query: str, 
        chunks: List[Dict[str, Any]],
        plan: Optional[Dict[str, Any]] = None
    ) -> Task:
        """
        Create a reasoning task for the agent.
        
        Args:
            agent: Reasoning agent instance
            query: Original student query
            chunks: Retrieved lecture chunks
            plan: Optional planning context
        
        Returns:
            CrewAI Task
        """
        
        # Format chunks for context
        chunks_text = "\n\n---\n\n".join([
            f"CHUNK {i+1}:\n"
            f"Lecture {chunk.get('metadata', {}).get('lecture_no', 'Unknown')}: "
            f"{chunk.get('metadata', {}).get('lecture_name', 'Unknown')}\n"
            f"Content: {chunk.get('page_content', chunk.get('content', ''))}\n"
            f"Score: {chunk.get('score', 'N/A')}"
            for i, chunk in enumerate(chunks)
        ])
        
        task_description = f"""Synthesize a clear, well-cited answer to the student's query.

STUDENT QUERY: "{query}"

RETRIEVED LECTURE CHUNKS:
{chunks_text}

YOUR TASK:
1. Read all {len(chunks)} chunks carefully
2. Identify information relevant to the query
3. Synthesize a coherent answer using ONLY this information
4. Add inline citations [Lecture X: Title] for every claim
5. Use pedagogical structure: Definition → Explanation → Examples
6. If information is missing, state "Not found in provided lectures"

REMEMBER:
- Zero hallucination tolerance
- Every factual claim needs a citation
- Use content from chunks ONLY
- Maintain academic clarity

Provide your answer in markdown format.
"""
        
        task = Task(
            description=task_description,
            agent=agent,
            expected_output="Markdown-formatted answer with inline citations to lecture sources"
        )
        
        return task


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_reasoning_agent(
    llm,
    strict_mode: bool = True,
    verbose: bool = True,
    **kwargs
) -> Agent:
    """
    Convenience function to create a Reasoning Agent.
    
    Args:
        llm: Language model instance
        strict_mode: Enable strict grounding enforcement
        verbose: Enable verbose output
        **kwargs: Additional config parameters
    
    Returns:
        Configured Reasoning Agent
    
    Example:
        >>> from langchain_community.llms import Ollama
        >>> llm = Ollama(model="mistral", temperature=0.1)
        >>> reasoning = create_reasoning_agent(llm, strict_mode=True)
    """
    
    config_dict = {}
    for key in ['role', 'goal', 'backstory', 'max_iter', 'temperature']:
        if key in kwargs:
            config_dict[key] = kwargs[key]
    
    config_dict['verbose'] = verbose
    config = ReasoningAgentConfig(**config_dict)
    
    return ReasoningAgent.create(llm, config, strict_mode, verbose)


def create_reasoning_task(
    agent: Agent, 
    query: str, 
    chunks: List[Dict[str, Any]],
    plan: Optional[Dict[str, Any]] = None
) -> Task:
    """
    Create reasoning task.
    
    Args:
        agent: Reasoning agent
        query: User query
        chunks: Retrieved chunks
        plan: Optional planner output
    
    Returns:
        Task for answer synthesis
    """
    return ReasoningAgent.create_task(agent, query, chunks, plan)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Reasoning Agent...")
    
    from langchain_community.llms import Ollama
    
    # Create LLM
    llm = Ollama(model="mistral", temperature=0.1)
    
    # Create agent
    reasoning = create_reasoning_agent(llm, strict_mode=True, verbose=True)
    print(f"✓ Created: {reasoning.role}")
    
    # Create test task
    test_query = "What is thrust?"
    test_chunks = [
        {
            "page_content": "Thrust is the force that propels a rocket...",
            "metadata": {"lecture_no": 3, "lecture_name": "Ascent Mission"},
            "score": 0.85
        }
    ]
    task = create_reasoning_task(reasoning, test_query, test_chunks)
    print(f"✓ Created task for query: {test_query}")
    
    print("\n✓ Reasoning Agent ready!")
