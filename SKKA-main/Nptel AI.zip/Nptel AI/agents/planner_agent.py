"""
Planner Agent for NPTEL Agentic RAG System
===========================================

The Planner Agent analyzes student queries and creates optimal
retrieval strategies.

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
from typing import Dict, Any, Optional
from dataclasses import dataclass
from crewai import Agent, Task

logger = logging.getLogger(__name__)


# ============================================================================
# AGENT CONFIGURATION
# ============================================================================

@dataclass
class PlannerAgentConfig:
    """Configuration for Planner Agent"""
    
    role: str = "Academic Query Strategist"
    
    goal: str = """Analyze student queries about NPTEL courses and create an optimal 
    retrieval strategy. Determine query type, complexity, and the best approach 
    to find relevant lecture content."""
    
    backstory: str = """You are an expert in understanding academic questions from 
    engineering and science students. You excel at:
    
    - Identifying the core concepts in a question
    - Determining if a question requires simple facts, explanations, comparisons, or multi-step reasoning
    - Breaking complex questions into retrievable sub-queries
    - Recognizing when a question needs specific course context
    - Assessing the depth of answer needed
    
    Your analysis guides the entire retrieval and reasoning process, so accuracy 
    is critical. You never make assumptions about what content exists - you plan 
    retrieval strategies that will verify availability."""
    
    verbose: bool = True
    allow_delegation: bool = False
    max_iter: int = 3


# ============================================================================
# SYSTEM PROMPT
# ============================================================================

PLANNER_SYSTEM_PROMPT = """You are an expert Academic Query Strategist for NPTEL courses.

YOUR TASK:
Analyze student queries and create a structured retrieval plan.

OUTPUT FORMAT (Always respond with this exact JSON structure):
{
  "query_type": "factual|comparison|explanation|multi_step|procedural",
  "complexity": "simple|medium|complex",
  "core_concepts": ["concept1", "concept2"],
  "sub_queries": ["sub_query1", "sub_query2"],
  "estimated_chunks": 5,
  "filters": {
    "discipline": "optional_discipline",
    "course_name": "optional_course"
  },
  "strategy": "broad_search|course_specific|multi_pass",
  "reasoning": "Brief explanation of your plan"
}

QUERY TYPE DEFINITIONS:
- factual: Simple fact lookup (Who? What? When?)
- comparison: Comparing 2+ concepts (Difference between X and Y?)
- explanation: How/Why questions requiring detailed explanation
- multi_step: Questions requiring multiple reasoning steps
- procedural: Step-by-step process questions (How to do X?)

COMPLEXITY LEVELS:
- simple: Can be answered with 1-2 chunks (factual queries)
- medium: Needs 3-5 chunks (explanations, comparisons)
- complex: Needs 5-10 chunks (multi-step, comprehensive topics)

FILTER RECOMMENDATIONS:
- Only suggest filters if query explicitly mentions course/discipline
- Example: "in machine learning course" → {"discipline": "Computer Science"}
- Don't over-filter - broad search is often better

STRATEGY OPTIONS:
- broad_search: Search across all courses (default)
- course_specific: User mentioned specific course
- multi_pass: Complex query needs iterative refinement

EXAMPLES:

Query: "What is thrust in rockets?"
{
  "query_type": "explanation",
  "complexity": "medium",
  "core_concepts": ["thrust", "rockets", "propulsion"],
  "sub_queries": ["thrust definition", "thrust calculation", "rocket propulsion"],
  "estimated_chunks": 5,
  "filters": {"discipline": "Aerospace Engineering"},
  "strategy": "broad_search",
  "reasoning": "Explanation query requiring definition and application examples"
}

Query: "Difference between supervised and unsupervised learning?"
{
  "query_type": "comparison",
  "complexity": "medium",
  "core_concepts": ["supervised learning", "unsupervised learning"],
  "sub_queries": ["supervised learning definition", "unsupervised learning definition", "comparison"],
  "estimated_chunks": 6,
  "filters": {"discipline": "Computer Science"},
  "strategy": "broad_search",
  "reasoning": "Comparison query needs separate definitions then comparison"
}

Query: "Who is Prof. Ashok Joshi?"
{
  "query_type": "factual",
  "complexity": "simple",
  "core_concepts": ["Prof. Ashok Joshi", "professor"],
  "sub_queries": ["Ashok Joshi"],
  "estimated_chunks": 2,
  "filters": {},
  "strategy": "broad_search",
  "reasoning": "Simple factual query about professor"
}

IMPORTANT:
- Always output valid JSON
- Be conservative with filters (prefer broad search)
- estimated_chunks should match complexity
- sub_queries help retriever formulate better searches
"""


# ============================================================================
# PLANNER AGENT CLASS
# ============================================================================

class PlannerAgent:
    """
    Planner Agent - Query Analysis & Strategy Creation
    
    This agent is the first in the pipeline. It analyzes the student's
    query and creates a structured plan for retrieval.
    """
    
    @staticmethod
    def create(
        llm,
        config: Optional[PlannerAgentConfig] = None,
        verbose: bool = True
    ) -> Agent:
        """
        Create a Planner Agent instance.
        
        Args:
            llm: Language model instance (Ollama/Mistral)
            config: Optional agent configuration
            verbose: Enable verbose output
        
        Returns:
            Configured CrewAI Agent
        """
        
        cfg = config or PlannerAgentConfig()
        
        agent = Agent(
            role=cfg.role,
            goal=cfg.goal,
            backstory=PLANNER_SYSTEM_PROMPT,
            verbose=cfg.verbose if not verbose else True,
            allow_delegation=cfg.allow_delegation,
            llm=llm,
            max_iter=cfg.max_iter,
            memory=True
        )
        
        if verbose:
            logger.info(f"✓ Created Planner Agent: {cfg.role}")
        
        return agent
    
    @staticmethod
    def create_task(agent: Agent, query: str) -> Task:
        """
        Create a planning task for the agent.
        
        Args:
            agent: Planner agent instance
            query: Student query to analyze
        
        Returns:
            CrewAI Task
        """
        
        task_description = f"""Analyze this student query and create a retrieval plan:

QUERY: "{query}"

Your task:
1. Classify the query type (factual, comparison, explanation, multi_step, procedural)
2. Assess complexity (simple, medium, complex)
3. Extract core concepts
4. Generate sub-queries for better retrieval
5. Estimate chunks needed
6. Recommend filters (only if query mentions specific course/discipline)
7. Choose retrieval strategy

Respond with the exact JSON format specified in your instructions.
"""
        
        task = Task(
            description=task_description,
            agent=agent,
            expected_output="JSON object with query analysis and retrieval plan"
        )
        
        return task


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_planner_agent(
    llm,
    verbose: bool = True,
    **kwargs
) -> Agent:
    """
    Convenience function to create a Planner Agent.
    
    Args:
        llm: Language model instance
        verbose: Enable verbose output
        **kwargs: Additional config parameters
    
    Returns:
        Configured Planner Agent
    
    Example:
        >>> from langchain_community.llms import Ollama
        >>> llm = Ollama(model="mistral", temperature=0.3)
        >>> planner = create_planner_agent(llm, verbose=True)
    """
    
    config_dict = {}
    for key in ['role', 'goal', 'backstory', 'max_iter']:
        if key in kwargs:
            config_dict[key] = kwargs[key]
    
    config_dict['verbose'] = verbose
    config = PlannerAgentConfig(**config_dict)
    
    return PlannerAgent.create(llm, config, verbose)


def create_planning_task(agent: Agent, query: str) -> Task:
    """
    Create planning task.
    
    Args:
        agent: Planner agent
        query: User query
    
    Returns:
        Task for query planning
    """
    return PlannerAgent.create_task(agent, query)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Planner Agent...")
    
    from langchain_community.llms import Ollama
    
    # Create LLM
    llm = Ollama(model="mistral", temperature=0.3)
    
    # Create agent
    planner = create_planner_agent(llm, verbose=True)
    print(f"✓ Created: {planner.role}")
    
    # Create task
    test_query = "What is thrust in rockets?"
    task = create_planning_task(planner, test_query)
    print(f"✓ Created task for query: {test_query}")
    
    print("\n✓ Planner Agent ready!")
