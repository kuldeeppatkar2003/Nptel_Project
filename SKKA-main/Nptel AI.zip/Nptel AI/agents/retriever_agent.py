"""
Retriever Agent for NPTEL Agentic RAG System
=============================================

The Retriever Agent executes semantic search based on the
Planner's strategy.

Author: NPTEL Agentic RAG Team
Date: January 2026
"""

import logging
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
from crewai import Agent, Task

logger = logging.getLogger(__name__)


# ============================================================================
# AGENT CONFIGURATION
# ============================================================================

@dataclass
class RetrieverAgentConfig:
    """Configuration for Retriever Agent"""
    
    role: str = "Knowledge Retrieval Specialist"
    
    goal: str = """Execute semantic search in the NPTEL lecture database and retrieve 
    the most relevant content for answering student questions. Ensure high-quality 
    retrieval through intelligent querying and filtering."""
    
    backstory: str = """You are a retrieval expert with deep knowledge of information 
    retrieval systems. You understand:
    
    - How to formulate effective search queries from natural language questions
    - When to use metadata filters (course, week, lecture) vs. broad search
    - How to assess retrieval quality based on similarity scores and diversity
    - When retrieval quality is insufficient and re-searching is needed
    - How to balance precision (relevant results) with recall (comprehensive coverage)
    
    You work with a vector database containing NPTEL lecture chunks.
    Your job is to find the exact content needed to answer each question accurately."""
    
    verbose: bool = True
    allow_delegation: bool = False
    max_iter: int = 5


# ============================================================================
# SYSTEM PROMPT
# ============================================================================

RETRIEVER_SYSTEM_PROMPT = """You are a Knowledge Retrieval Specialist for NPTEL lectures.

YOUR TASK:
Execute semantic search to find the most relevant lecture chunks for answering the query.

YOU HAVE ACCESS TO:
- chromadb_search: Searches NPTEL lecture database

TOOL USAGE:
chromadb_search(query="your search query", k=10, course_name="optional")

Parameters:
- query (str): Search query text
- k (int): Number of results to retrieve (default: 10, max: 20)
- course_name (str): Optional course filter
  Examples:
  - "Machine Learning"
- week_no (int): Optional week filter
- lecture_no (int): Optional lecture filter

RETRIEVAL STRATEGY:

1. INITIAL SEARCH:
   - Use the original query first
   - Set k based on complexity: simple=3, medium=5-7, complex=8-10
   - Apply filters from planner (if any)

2. QUALITY ASSESSMENT:
   - Check similarity scores: high (>0.7), medium (0.5-0.7), low (<0.5)
   - Evaluate diversity: Results from multiple lectures = good
   - Verify relevance: Do chunks actually relate to query?

3. REFINEMENT (if needed):
   - If avg_score < 0.5: Reformulate query (broader/simpler terms)
   - If results too similar: Increase k, remove filters
   - If no results: Try sub-queries from planner

4. OUTPUT FORMAT:
   Return your findings as a structured report:
   
   RETRIEVAL REPORT:
   - Query used: [actual query sent to tool]
   - Results retrieved: [number]
   - Average score: [score]
   - Confidence: [high/medium/low]
   - Top 3 chunks summary:
     1. [Lecture X]: [brief content summary]
     2. [Lecture Y]: [brief content summary]
     3. [Lecture Z]: [brief content summary]
   
   Then provide the full chunks data.

EXAMPLES:

Example 1 - Good retrieval:
Query: "What is thrust in rockets?"
Action: chromadb_search(query="thrust rockets propulsion", k=5, course_name="Aerospace Engineering")
Result: 5 chunks, avg_score=0.82 → HIGH CONFIDENCE

Example 2 - Low quality, needs refinement:
Query: "Explain ML algorithms"
First try: chromadb_search(query="ML algorithms", k=5) → avg_score=0.45
Refinement: chromadb_search(query="machine learning algorithms classification regression", k=8) → avg_score=0.71
Result: IMPROVED

Example 3 - No results, use sub-queries:
Query: "How does gradient descent work?"
First try: chromadb_search(query="gradient descent", k=5) → 0 results
Refinement: chromadb_search(query="optimization algorithm learning rate", k=7) → 3 results

IMPORTANT RULES:
- Always call the tool (don't skip retrieval)
- Try at least 1-2 searches before giving up
- Prefer broad searches over restrictive filters
- Report honestly about retrieval quality
- Include actual chunk content in your final output
"""


# ============================================================================
# RETRIEVER AGENT CLASS
# ============================================================================

class RetrieverAgent:
    """
    Retriever Agent - Semantic Search Execution
    
    This agent executes searches based on the Planner's strategy and
    returns relevant lecture chunks.
    """
    
    @staticmethod
    def create(
        llm,
        tools: List,
        config: Optional[RetrieverAgentConfig] = None,
        verbose: bool = True
    ) -> Agent:
        """
        Create a Retriever Agent instance.
        
        Args:
            llm: Language model instance
            tools: List of tools (MUST include chromadb_search_tool)
            config: Optional agent configuration
            verbose: Enable verbose output
        
        Returns:
            Configured CrewAI Agent
        """
        
        cfg = config or RetrieverAgentConfig()
        
        if not tools:
            logger.warning("⚠ Retriever Agent created without tools!")
        
        agent = Agent(
            role=cfg.role,
            goal=cfg.goal,
            backstory=RETRIEVER_SYSTEM_PROMPT,
            verbose=cfg.verbose if not verbose else True,
            allow_delegation=cfg.allow_delegation,
            llm=llm,
            tools=tools,
            max_iter=cfg.max_iter,
            memory=True
        )
        
        if verbose:
            logger.info(f"✓ Created Retriever Agent with {len(tools)} tools")
        
        return agent
    
    @staticmethod
    def create_task(agent: Agent, query: str, plan: Dict[str, Any]) -> Task:
        """
        Create a retrieval task for the agent.
        
        Args:
            agent: Retriever agent instance
            query: Original student query
            plan: Planning output from Planner Agent
        
        Returns:
            CrewAI Task
        """
        
        task_description = f"""Execute semantic search to find relevant lecture chunks.

ORIGINAL QUERY: "{query}"

PLANNER'S ANALYSIS:
- Query Type: {plan.get('query_type', 'unknown')}
- Complexity: {plan.get('complexity', 'medium')}
- Core Concepts: {plan.get('core_concepts', [])}
- Sub-queries: {plan.get('sub_queries', [])}
- Recommended Chunks: {plan.get('estimated_chunks', 5)}
- Filters: {plan.get('filters', {})}
- Strategy: {plan.get('strategy', 'broad_search')}

YOUR TASK:
1. Use chromadb_search_tool to find relevant lecture chunks
2. Start with k={plan.get('estimated_chunks', 5)} results
3. Apply filters: {plan.get('filters', {})} (if any)
4. Assess retrieval quality (similarity scores, diversity)
5. Refine search if quality is low (avg_score < 0.5)
6. Provide a structured retrieval report with the chunks

Remember: You can call the tool multiple times to improve results.
"""
        
        task = Task(
            description=task_description,
            agent=agent,
            expected_output="Retrieval report with lecture chunks, scores, and quality assessment"
        )
        
        return task


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_retriever_agent(
    llm,
    tools: List,
    verbose: bool = True,
    **kwargs
) -> Agent:
    """
    Convenience function to create a Retriever Agent.
    
    Args:
        llm: Language model instance
        tools: List of tools (chromadb_search_tool, etc.)
        verbose: Enable verbose output
        **kwargs: Additional config parameters
    
    Returns:
        Configured Retriever Agent
    
    Example:
        >>> from langchain_community.llms import Ollama
        >>> from tools.chromadb_tool import chromadb_search_tool
        >>> 
        >>> llm = Ollama(model="mistral", temperature=0.1)
        >>> retriever = create_retriever_agent(llm, tools=[chromadb_search_tool])
    """
    
    config_dict = {}
    for key in ['role', 'goal', 'backstory', 'max_iter']:
        if key in kwargs:
            config_dict[key] = kwargs[key]
    
    config_dict['verbose'] = verbose
    config = RetrieverAgentConfig(**config_dict)
    
    return RetrieverAgent.create(llm, tools, config, verbose)


def create_retrieval_task(agent: Agent, query: str, plan: Dict[str, Any]) -> Task:
    """
    Create retrieval task.
    
    Args:
        agent: Retriever agent
        query: User query
        plan: Planner output
    
    Returns:
        Task for semantic search
    """
    return RetrieverAgent.create_task(agent, query, plan)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Retriever Agent...")
    
    from langchain_community.llms import Ollama
    
    # Create LLM
    llm = Ollama(model="mistral", temperature=0.1)
    
    # Create agent (with empty tools for testing)
    retriever = create_retriever_agent(llm, tools=[], verbose=True)
    print(f"✓ Created: {retriever.role}")
    
    # Create task
    test_query = "What is thrust in rockets?"
    test_plan = {
        "query_type": "explanation",
        "complexity": "medium",
        "estimated_chunks": 5,
        "filters": {"discipline": "Aerospace Engineering"}
    }
    task = create_retrieval_task(retriever, test_query, test_plan)
    print(f"✓ Created task for query: {test_query}")
    
    print("\n✓ Retriever Agent ready!")
